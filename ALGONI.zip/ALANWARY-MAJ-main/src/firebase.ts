import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  doc,
  onSnapshot,
  setDoc,
  getDocFromServer
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

const config = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfig.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfig.authDomain,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfig.projectId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfig.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfig.messagingSenderId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || firebaseConfig.appId,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || firebaseConfig.measurementId,
};

const app = initializeApp(config);
export const auth = getAuth(app);

const databaseId = import.meta.env.VITE_FIREBASE_DATABASE_ID ||
  (config.projectId === firebaseConfig.projectId ? firebaseConfig.firestoreDatabaseId : undefined);

export const db = (() => {
  const cacheOptions = typeof window !== 'undefined'
    ? { localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }) }
    : {};
  try {
    return (databaseId && databaseId !== '(default)')
      ? initializeFirestore(app, cacheOptions, databaseId)
      : initializeFirestore(app, cacheOptions);
  } catch {
    return (databaseId && databaseId !== '(default)')
      ? getFirestore(app, databaseId)
      : getFirestore(app);
  }
})();

// Skill-mandated operation types for error tracing
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  return errInfo;
}

// Test connection on boot (as required by firebase-skill)
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    updateSyncStatus(true, null);
  } catch (error: any) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or starting up:', error.message);
      updateSyncStatus(false, 'Connexion Firebase en attente (hors ligne)');
    }
  }
}
testConnection();

const STORAGE_PREFIX = 'odoo_erp_store_v1_';

export interface SyncStatus {
  connected: boolean;
  error: string | null;
  projectId: string;
  databaseId?: string;
  lastSync: string | null;
  pendingCount?: number;
}

type SyncStatusListener = (status: SyncStatus) => void;
const syncStatusListeners = new Set<SyncStatusListener>();
let currentSyncStatus: SyncStatus = {
  connected: false,
  error: null,
  projectId: config.projectId,
  databaseId: databaseId || '(default)',
  lastSync: null,
  pendingCount: 0
};

export function getSyncStatus(): SyncStatus {
  return currentSyncStatus;
}

export function onSyncStatusChange(listener: SyncStatusListener) {
  syncStatusListeners.add(listener);
  listener(currentSyncStatus);
  return () => {
    syncStatusListeners.delete(listener);
  };
}

function updateSyncStatus(connected: boolean, error: string | null = null) {
  currentSyncStatus = {
    connected,
    error,
    projectId: config.projectId,
    databaseId: databaseId || '(default)',
    lastSync: connected ? new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : currentSyncStatus.lastSync,
    pendingCount: currentSyncStatus.pendingCount
  };
  syncStatusListeners.forEach(listener => listener(currentSyncStatus));
}

function syncLocalCache<T>(key: string, value: T) {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('Failed to update local cache for key:', key, e);
  }
}

// Generic function to sync state with Firestore document in real-time
export function subscribeToDoc<T>(
  docKey: string,
  onData: (data: T) => void,
  initialValue: T
) {
  const docRef = doc(db, 'app_data', docKey);
  
  // Listen for real-time updates
  const unsubscribe = onSnapshot(docRef, (snapshot) => {
    updateSyncStatus(true, null);
    if (snapshot.exists()) {
      const data = snapshot.data();
      if (data && 'value' in data) {
        const val = data.value as T;
        onData(val);
        syncLocalCache(docKey, val);
      }
    } else {
      // First time initialization in Firestore
      setDoc(docRef, { value: initialValue, updatedAt: new Date().toISOString() })
        .then(() => {
          updateSyncStatus(true, null);
        })
        .catch(err => {
          handleFirestoreError(err, OperationType.CREATE, `app_data/${docKey}`);
          updateSyncStatus(false, err.message || 'Erreur d\'écriture Firestore');
        });
      onData(initialValue);
      syncLocalCache(docKey, initialValue);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, `app_data/${docKey}`);
    updateSyncStatus(false, error.message || 'Erreur de connexion Firestore');
  });

  return unsubscribe;
}

// Function to update state in Firestore, triggering real-time sync across all devices
export async function updateDocValue<T>(docKey: string, value: T): Promise<{ success: boolean; error?: string }> {
  // Update local cache immediately for instantaneous UI response
  syncLocalCache(docKey, value);

  try {
    const docRef = doc(db, 'app_data', docKey);
    await setDoc(docRef, { value, updatedAt: new Date().toISOString() });
    updateSyncStatus(true, null);
    return { success: true };
  } catch (error: any) {
    handleFirestoreError(error, OperationType.WRITE, `app_data/${docKey}`);
    const message = error?.message || 'Erreur lors de la sauvegarde Firestore';
    updateSyncStatus(false, message);
    return { success: false, error: message };
  }
}

// Force immediate full cloud sync for all collections
export async function forceSaveAllToCloud(allCollections: Record<string, any>): Promise<{
  success: boolean;
  savedKeys: string[];
  failedKeys: string[];
  timestamp: string;
}> {
  const savedKeys: string[] = [];
  const failedKeys: string[] = [];
  const timestamp = new Date().toISOString();

  const entries = Object.entries(allCollections);
  for (const [key, val] of entries) {
    try {
      syncLocalCache(key, val);
      const docRef = doc(db, 'app_data', key);
      await setDoc(docRef, { value: val, updatedAt: timestamp });
      savedKeys.push(key);
    } catch (err) {
      console.error(`Error force saving ${key} to Firestore:`, err);
      failedKeys.push(key);
    }
  }

  const allSuccess = failedKeys.length === 0;
  updateSyncStatus(allSuccess, allSuccess ? null : `Échec de sauvegarde sur: ${failedKeys.join(', ')}`);

  return {
    success: allSuccess,
    savedKeys,
    failedKeys,
    timestamp
  };
}



