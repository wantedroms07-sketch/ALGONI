import React, { useState, useEffect } from 'react';
import {
  Settings,
  Building,
  Save,
  Download,
  Upload,
  CheckCircle2,
  Database,
  Image as ImageIcon,
  Trash2,
  FileText,
  Sparkles,
  Lock,
  ShieldCheck,
  RefreshCw,
  HardDrive,
  Server,
  FileJson,
  AlertCircle
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import { onSyncStatusChange, getSyncStatus, SyncStatus } from '../../firebase';

export const SettingsView: React.FC = () => {
  const {
    companySettings,
    updateCompanySettings,
    exportDatabaseBackup,
    importDatabaseBackup,
    forceCloudSync,
    isAdmin,
    products,
    invoices,
    customers,
    suppliers,
    purchases,
    payments,
    stockMovements,
    categories,
    users
  } = useERP();

  const [activeTab, setActiveTab] = useState<'general' | 'logo' | 'backup'>('general');
  const [formData, setFormData] = useState({ ...companySettings });
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Cloud Sync & Restore states
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(getSyncStatus);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    const unsub = onSyncStatusChange(setSyncStatus);
    return unsub;
  }, []);

  const handleForceSync = async () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    try {
      const res = await forceCloudSync();
      if (res.success) {
        setSyncFeedback({ type: 'success', message: res.message });
      } else {
        setSyncFeedback({ type: 'error', message: res.message });
      }
    } catch (err: any) {
      setSyncFeedback({ type: 'error', message: err?.message || 'Erreur lors de la synchronisation cloud' });
    } finally {
      setIsSyncing(false);
      setTimeout(() => setSyncFeedback(null), 6000);
    }
  };

  const handleRestoreFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAdmin) {
      alert("Action réservée : Seul l'administrateur peut restaurer la base de données.");
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    const confirmed = window.confirm(
      "ATTENTION : Cette action va remplacer les données actuelles par celles du fichier de sauvegarde. Voulez-vous continuer ?"
    );
    if (!confirmed) return;

    setIsRestoring(true);
    setRestoreFeedback(null);

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const parsed = JSON.parse(text);
        const res = await importDatabaseBackup(parsed);
        if (res.success) {
          setRestoreFeedback({ type: 'success', message: res.message });
        } else {
          setRestoreFeedback({ type: 'error', message: res.message });
        }
      } catch (err: any) {
        setRestoreFeedback({ type: 'error', message: "Fichier JSON non valide ou corrompu." });
      } finally {
        setIsRestoring(false);
        setTimeout(() => setRestoreFeedback(null), 7000);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) {
      alert("Action réservée : Seul l'administrateur peut modifier les paramètres de l'entreprise.");
      return;
    }
    updateCompanySettings(formData);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAdmin) {
      alert("Action réservée : Seul l'administrateur peut modifier le logo.");
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Le fichier image est trop volumineux (max 5 Mo).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setFormData(prev => ({ ...prev, logo: result }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setFormData(prev => ({ ...prev, logo: '' }));
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary-50 dark:bg-primary-950/60 text-primary-600 dark:text-primary-400 flex items-center justify-center font-bold">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Paramètres de l'Entreprise & Factures
            </h2>
            <p className="text-xs text-slate-500">
              Coordonnées légales, couleur du thème, logo officiel de facture, devises et sauvegarde.
            </p>
          </div>
        </div>

        {saveSuccess && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 text-xs font-bold rounded-xl animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>Paramètres enregistrés !</span>
          </div>
        )}
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-700 pb-1">
        <button
          onClick={() => setActiveTab('general')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'general'
              ? 'bg-primary-600 text-white shadow-md shadow-primary-600/20'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Informations Légales & Thème</span>
        </button>

        <button
          onClick={() => setActiveTab('logo')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'logo'
              ? 'bg-primary-600 text-white shadow-md shadow-primary-600/20'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          <ImageIcon className="w-4 h-4" />
          <span>Logo & En-tête Facture</span>
          {formData.logo && (
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('backup')}
          className={`px-4 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'backup'
              ? 'bg-primary-600 text-white shadow-md shadow-primary-600/20'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          <Database className="w-4 h-4" />
          <span>Sauvegardes & Sécurité Cloud</span>
          <span className={`w-2 h-2 rounded-full ${syncStatus.connected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
        </button>
      </div>

      {/* TAB 1: GENERAL LEGAL INFO & THEME */}
      {activeTab === 'general' && (
        <form onSubmit={handleSave} className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-6">
          {/* Section 1: Primary Color Accent */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-primary-600 dark:text-primary-400 font-bold text-xs">
                <Sparkles className="w-4 h-4" />
                <span>Couleur Principale de l'Application</span>
              </div>
              <span className="text-[11px] font-semibold text-slate-500 uppercase">
                {formData.primaryColor || 'emerald'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              Choisissez la couleur d'accentuation principale pour tous les boutons, menus, badges et surbrillances de l'ERP.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-1">
              {[
                { id: 'emerald', name: 'Vert Émeraude', bg: 'bg-emerald-600', ring: 'ring-emerald-500' },
                { id: 'blue', name: 'Bleu Royal', bg: 'bg-blue-600', ring: 'ring-blue-500' },
                { id: 'violet', name: 'Violet Moderne', bg: 'bg-violet-600', ring: 'ring-violet-500' },
                { id: 'indigo', name: 'Indigo Classique', bg: 'bg-indigo-600', ring: 'ring-indigo-500' },
                { id: 'teal', name: 'Teal Océan', bg: 'bg-teal-600', ring: 'ring-teal-500' },
                { id: 'rose', name: 'Rose Crimson', bg: 'bg-rose-600', ring: 'ring-rose-500' },
                { id: 'amber', name: 'Amber Or', bg: 'bg-amber-600', ring: 'ring-amber-500' },
              ].map(color => (
                <button
                  key={color.id}
                  type="button"
                  onClick={() => setFormData(prev => ({ ...prev, primaryColor: color.id as any }))}
                  className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-bold transition-all ${
                    (formData.primaryColor || 'emerald') === color.id
                      ? 'border-slate-800 dark:border-white bg-white dark:bg-slate-800 shadow-sm ring-2 ring-primary-500'
                      : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full ${color.bg} shadow-xs`} />
                  <span className="truncate">{color.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 pb-3 border-b border-slate-100 dark:border-slate-700 text-primary-600 font-bold text-sm">
            <Building className="w-4 h-4" />
            <span>Raison Sociale & Coordonnées</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Raison Sociale / Nom Commercial
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={e => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Devise Principale
              </label>
              <select
                value={formData.currencySymbol}
                onChange={e => setFormData({ ...formData, currencySymbol: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white font-bold"
              >
                <option value="CFA">Franc CFA (XOF/XAF)</option>
                <option value="€">Euro (€)</option>
                <option value="$">US Dollar ($)</option>
                <option value="MAD">Dirham Marocain (MAD)</option>
                <option value="DZD">Dinar Algérien (DZD)</option>
                <option value="TND">Dinar Tunisien (TND)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Téléphone Contact
              </label>
              <input
                type="text"
                value={formData.phone}
                onChange={e => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Email Officiel
              </label>
              <input
                type="email"
                value={formData.email}
                onChange={e => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                NIF (Numéro d'Identification Fiscale)
              </label>
              <input
                type="text"
                value={formData.nif}
                onChange={e => setFormData({ ...formData, nif: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                RCCM (Registre du Commerce)
              </label>
              <input
                type="text"
                value={formData.rccm}
                onChange={e => setFormData({ ...formData, rccm: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Taux de TVA par Défaut (%)
              </label>
              <input
                type="number"
                value={formData.defaultVatRate}
                onChange={e => setFormData({ ...formData, defaultVatRate: Number(e.target.value) })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Adresse Physique
              </label>
              <input
                type="text"
                value={formData.address}
                onChange={e => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Ville
              </label>
              <input
                type="text"
                value={formData.city}
                onChange={e => setFormData({ ...formData, city: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Pays
              </label>
              <input
                type="text"
                value={formData.country}
                onChange={e => setFormData({ ...formData, country: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3">
            {!isAdmin ? (
              <span className="px-3 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 rounded-xl inline-flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                Lecture seule (Admin requis)
              </span>
            ) : (
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-bold bg-primary-600 hover:bg-primary-700 text-white rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Enregistrer la Configuration</span>
              </button>
            )}
          </div>
        </form>
      )}

      {/* TAB 2: LOGO & FACTURE */}
      {activeTab === 'logo' && (
        <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
            <div className="flex items-center gap-2 text-primary-600 dark:text-primary-400 font-bold text-sm">
              <ImageIcon className="w-5 h-5" />
              <span>Logo Officiel & Affichage sur les Factures</span>
            </div>
          </div>

          <p className="text-xs text-slate-500">
            Téléchargez l'image de votre logo depuis votre disque dur local (PNG, JPG, SVG, WEBP). Ce logo sera immédiatement affiché sur toutes vos <strong>factures imprimées, reçus et exports PDF</strong>.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
            {/* Logo Picker Controls */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Upload className="w-4 h-4 text-primary-500" />
                <span>Sélectionner une Image Locale</span>
              </h4>

              <div className="space-y-3">
                <label
                  htmlFor="logo-file-input"
                  className="w-full py-3 px-4 bg-primary-600 hover:bg-primary-700 text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Parcourir mon ordinateur...</span>
                  <input
                    type="file"
                    id="logo-file-input"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </label>

                {formData.logo && (
                  <button
                    type="button"
                    onClick={handleRemoveLogo}
                    className="w-full py-2 px-3 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Supprimer le Logo Actuel</span>
                  </button>
                )}
              </div>

              {/* Alternative Image URL */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-1.5">
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                  Ou coller une URL d'image externe :
                </label>
                <input
                  type="text"
                  placeholder="https://exemple.com/logo.png"
                  value={formData.logo}
                  onChange={e => setFormData({ ...formData, logo: e.target.value })}
                  className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-primary-500 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Live Invoice Header Preview */}
            <div className="p-5 rounded-2xl bg-slate-900 text-white space-y-4">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-bold flex items-center gap-1.5 text-primary-400">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Aperçu sur Facture Officielle</span>
                </span>
                <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">En-tête PDF / Impression</span>
              </div>

              <div className="p-4 rounded-xl bg-white text-slate-900 shadow-lg space-y-3">
                <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-3">
                    {formData.logo ? (
                      <img
                        src={formData.logo}
                        alt="Logo Aperçu"
                        className="w-14 h-14 object-contain rounded-lg border border-slate-200 bg-slate-50 p-1 shadow-xs"
                      />
                    ) : (
                      <div className="w-14 h-14 rounded-lg bg-primary-600 text-white font-black text-xl flex items-center justify-center shadow-xs">
                        WAD
                      </div>
                    )}
                    <div>
                      <h3 className="font-black text-primary-900 text-sm uppercase">{formData.name || 'Nom de la Société'}</h3>
                      <p className="text-[10px] text-slate-500">{formData.address || 'Adresse'}, {formData.city}</p>
                      <p className="text-[10px] text-slate-500">Tél: {formData.phone || '00 00 00 00'}</p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="font-mono font-bold text-xs text-primary-600">FACTURE #INV-2026</p>
                    <span className="inline-block px-2 py-0.5 text-[9px] font-bold bg-emerald-100 text-emerald-800 rounded-full">
                      PAYÉE
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-slate-400 italic">
                ✓ L'image apparaît automatiquement en haut à gauche de toutes vos factures client.
              </p>
            </div>
          </div>

          <div className="pt-3 flex items-center justify-end gap-3">
            {!isAdmin ? (
              <span className="px-3 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-700 rounded-xl inline-flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                Lecture seule (Admin requis)
              </span>
            ) : (
              <button
                onClick={handleSave}
                className="px-5 py-2.5 text-xs font-bold bg-primary-600 hover:bg-primary-700 text-white rounded-xl shadow-md transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Enregistrer le Logo</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: BACKUP & SECURITY */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          {/* Cloud Database Status Card */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-700">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 flex items-center justify-center">
                  <Database className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Base de Données Cloud (Firebase Firestore)
                  </h3>
                  <p className="text-xs text-slate-500">
                    ID: <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">{syncStatus.databaseId || 'ai-studio-odooerpstockvent-dedcde03-a4f0-4e35-8a51-5c8a1f378f21'}</span>
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                  syncStatus.connected
                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-400 dark:border-emerald-800'
                    : 'bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/60 dark:text-amber-400 dark:border-amber-800'
                }`}>
                  <span className={`w-2 h-2 rounded-full ${syncStatus.connected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
                  {syncStatus.connected ? 'Connecté & Enregistrement Actif' : 'Mode Cache Local'}
                </span>

                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950/60 dark:text-indigo-400 dark:border-indigo-800">
                  <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                  Règles ABAC & Protection Déployées
                </span>
              </div>
            </div>

            {/* Cloud Security Callout */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
                  <HardDrive className="w-4 h-4 text-primary-600" />
                  <span>Double Redondance</span>
                </div>
                <p className="text-slate-500 text-[11px] leading-relaxed">
                  Chaque saisie est écrite instantanément en cache local sécurisé puis propagée dans le Cloud Firestore.
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Protection Anti-Suppression</span>
                </div>
                <p className="text-slate-500 text-[11px] leading-relaxed">
                  Les règles Firestore interdisent la suppression globale de collections (<span className="font-mono text-emerald-600 font-semibold">allow delete: false</span>).
                </p>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 space-y-1">
                <div className="flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200">
                  <Server className="w-4 h-4 text-indigo-600" />
                  <span>Dernière Synchro Cloud</span>
                </div>
                <p className="text-slate-700 dark:text-slate-300 font-mono font-bold text-[12px]">
                  {syncStatus.lastSync ? syncStatus.lastSync : 'En cours de synchronisation...'}
                </p>
              </div>
            </div>

            {/* Force Sync Action */}
            <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-500">
                Vous pouvez déclencher une synchronisation et vérification forcée de toutes les tables vers Firestore.
              </div>

              <button
                type="button"
                onClick={handleForceSync}
                disabled={isSyncing}
                className="px-4 py-2.5 text-xs font-bold bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Synchronisation Cloud...' : 'Forcer la Sauvegarde Immédiate'}</span>
              </button>
            </div>

            {syncFeedback && (
              <div className={`p-3 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in ${
                syncFeedback.type === 'success'
                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                  : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
              }`}>
                {syncFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
                <span>{syncFeedback.message}</span>
              </div>
            )}
          </div>

          {/* Protected Live Records Summary */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-4">
            <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Volume des Données Enregistrées & Sécurisées
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Articles en Stock</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{products.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Factures & Ventes</span>
                <p className="text-lg font-black text-primary-600">{invoices.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Clients Enregistrés</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{customers.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Fournisseurs</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{suppliers.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Bons de Commande</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{purchases.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Règlements Encaissés</span>
                <p className="text-lg font-black text-emerald-600">{payments.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Mouvements Traçés</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{stockMovements.length}</p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-100 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 font-medium">Utilisateurs / Équipe</span>
                <p className="text-lg font-black text-slate-900 dark:text-white">{users.length}</p>
              </div>
            </div>
          </div>

          {/* Export & Restore JSON Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Export Card */}
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-purple-600 font-bold text-sm">
                  <Download className="w-4 h-4" />
                  <span>Exporter une Sauvegarde Complète (JSON)</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Génère un fichier JSON sécurisé contenant toutes les tables de la base de données, horodaté et prêt à être stocké hors-ligne sur clé USB ou disque dur.
                </p>
              </div>

              <button
                type="button"
                onClick={exportDatabaseBackup}
                className="w-full px-5 py-3 text-xs font-bold bg-purple-600 hover:bg-purple-700 text-white rounded-xl shadow-md shadow-purple-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Télécharger Sauvegarde JSON (.json)</span>
              </button>
            </div>

            {/* Restore Card */}
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-4 flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-indigo-600 font-bold text-sm">
                  <Upload className="w-4 h-4" />
                  <span>Restaurer une Sauvegarde JSON</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Chargez un fichier de sauvegarde préalablement exporté. Les données seront immédiatement restaurées et synchronisées dans Firestore.
                </p>
              </div>

              {!isAdmin ? (
                <div className="p-3 bg-slate-100 dark:bg-slate-700 rounded-xl text-xs text-slate-500 flex items-center gap-2">
                  <Lock className="w-4 h-4 text-slate-400" />
                  <span>Restauration réservée à l'administrateur</span>
                </div>
              ) : (
                <div>
                  <label className="w-full px-5 py-3 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2 cursor-pointer">
                    <Upload className="w-4 h-4" />
                    <span>{isRestoring ? 'Restauration en cours...' : 'Sélectionner Fichier JSON à Restaurer'}</span>
                    <input
                      type="file"
                      accept=".json"
                      onChange={handleRestoreFile}
                      disabled={isRestoring}
                      className="hidden"
                    />
                  </label>
                </div>
              )}
            </div>
          </div>

          {restoreFeedback && (
            <div className={`p-4 rounded-xl text-xs font-bold flex items-center gap-2 animate-in fade-in ${
              restoreFeedback.type === 'success'
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
            }`}>
              {restoreFeedback.type === 'success' ? <CheckCircle2 className="w-5 h-5 shrink-0" /> : <AlertCircle className="w-5 h-5 shrink-0" />}
              <span>{restoreFeedback.message}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
