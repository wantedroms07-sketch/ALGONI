import React, { useState } from 'react';
import {
  FileText,
  Search,
  Printer,
  Download,
  FileSpreadsheet,
  Plus,
  Minus,
  Eye,
  Edit,
  Trash2,
  Share2,
  X,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Phone,
  Mail,
  Send,
  User as UserIcon,
  Store,
  Calendar,
  DollarSign,
  Package,
  ShoppingCart,
  Save,
  RotateCcw,
  Check,
  AlertCircle,
  CreditCard,
  Lock,
  ShieldCheck
} from 'lucide-react';
import jsPDF from 'jspdf';
import * as XLSX from 'xlsx';
import { useERP } from '../../context/ERPContext';
import { Invoice, InvoiceItem, SaleType, PaymentMethod } from '../../types/erp';

export const InvoicesView: React.FC = () => {
  const {
    invoices,
    updateInvoice,
    deleteInvoice,
    addPaymentToInvoice,
    products,
    customers,
    stores,
    companySettings,
    currentUser,
    users,
    isAdmin,
    t
  } = useERP();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'paid' | 'partial' | 'unpaid'>('all');
  const [userFilter, setUserFilter] = useState<string>('all');

  // Selected Invoice for View/Print Modal
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);

  // Payment Modal State
  const [paymentInvoice, setPaymentInvoice] = useState<Invoice | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<string>('cash');
  const [paymentNotes, setPaymentNotes] = useState<string>('');

  // Editing Invoice State
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [editItems, setEditItems] = useState<InvoiceItem[]>([]);
  const [editCustomerId, setEditCustomerId] = useState<string>('');
  const [editCustomerName, setEditCustomerName] = useState<string>('');
  const [editCustomerPhone, setEditCustomerPhone] = useState<string>('');
  const [editSaleType, setEditSaleType] = useState<SaleType>('retail');
  const [editDate, setEditDate] = useState<string>('');
  const [editDueDate, setEditDueDate] = useState<string>('');
  const [editPaymentMethod, setEditPaymentMethod] = useState<PaymentMethod>('cash');
  const [editPaidAmount, setEditPaidAmount] = useState<number>(0);
  const [editDiscountAmount, setEditDiscountAmount] = useState<number>(0);
  const [editNotes, setEditNotes] = useState<string>('');
  const [editStoreName, setEditStoreName] = useState<string>('');
  const [editAdjustStock, setEditAdjustStock] = useState<boolean>(true);
  const [selectedProductToAdd, setSelectedProductToAdd] = useState<string>('');
  const [editProductSearch, setEditProductSearch] = useState<string>('');

  // Deleting Invoice State
  const [deletingInvoice, setDeletingInvoice] = useState<Invoice | null>(null);
  const [deleteRestoreStock, setDeleteRestoreStock] = useState<boolean>(true);

  // Notification Toast state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Filter Invoices (accessible to all connected devices and users)
  const filtered = invoices.filter(inv => {
    const matchesSearch =
      inv.invoiceNumber.toLowerCase().includes(search.toLowerCase()) ||
      inv.customerName.toLowerCase().includes(search.toLowerCase()) ||
      inv.customerPhone.includes(search) ||
      inv.createdBy.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;

    let matchesUser = true;
    if (userFilter !== 'all') {
      matchesUser = inv.createdBy === userFilter || inv.userId === userFilter;
    }

    return matchesSearch && matchesStatus && matchesUser;
  });

  // Export Excel
  const handleExportExcel = () => {
    const data = invoices.map(i => ({
      'N° Facture': i.invoiceNumber,
      Date: i.date,
      'Date Échéance': i.dueDate || i.date,
      Client: i.customerName,
      Téléphone: i.customerPhone,
      Type: i.saleType === 'wholesale' ? 'Vente Gros' : 'Vente Détail',
      'Nb Articles': i.items.reduce((sum, it) => sum + it.quantity, 0),
      'Montant Total (CFA)': i.totalAmount,
      'Montant Payé (CFA)': i.paidAmount,
      'Solde Restant (CFA)': i.remainingAmount,
      Statut: i.status === 'paid' ? 'Payée' : i.status === 'partial' ? 'Partielle' : 'Non Payée',
      'Établi par': i.createdBy,
      Boutique: i.storeName || 'Non spécifié',
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Factures Vente');
    XLSX.writeFile(wb, `Factures_Ventes_${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Generate jsPDF Document
  const handleExportPDF = (inv: Invoice) => {
    const doc = new jsPDF();

    // Background header bar
    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, 210, 32, 'F');

    // White title in header
    doc.setTextColor(255, 255, 255);
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(companySettings.name.toUpperCase(), 14, 18);

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`${companySettings.address} - ${companySettings.city}, ${companySettings.country} | Tél: ${companySettings.phone}`, 14, 25);

    // Invoice title block on right
    doc.setFontSize(14);
    doc.setFont('helvetica', 'bold');
    doc.text(`FACTURE N° ${inv.invoiceNumber}`, 140, 18);
    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Date : ${inv.date} | Statut : ${inv.status.toUpperCase()}`, 140, 25);

    // Reset text color
    doc.setTextColor(30, 41, 59);

    let startY = 40;

    // Company Logo if present
    if (companySettings.logo && companySettings.logo.startsWith('data:image')) {
      try {
        const format = companySettings.logo.includes('image/png') ? 'PNG' : 'JPEG';
        doc.addImage(companySettings.logo, format, 14, startY, 22, 22);
        startY += 26;
      } catch (err) {
        console.warn('Could not add logo to PDF:', err);
      }
    }

    // Customer Info Box
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.roundedRect(14, startY, 182, 24, 3, 3, 'FD');

    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('FACTURÉ À :', 18, startY + 8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Client : ${inv.customerName}`, 18, startY + 15);
    doc.text(`Téléphone : ${inv.customerPhone}`, 18, startY + 20);

    doc.setFont('helvetica', 'bold');
    doc.text('DÉTAILS VENTE :', 120, startY + 8);
    doc.setFont('helvetica', 'normal');
    doc.text(`Type : ${inv.saleType === 'wholesale' ? 'Vente en Gros' : 'Vente au Détail'}`, 120, startY + 15);
    doc.text(`Établi par : ${inv.createdBy || 'Administration'}`, 120, startY + 20);

    // Items Table Header
    let y = startY + 32;
    doc.setFillColor(15, 23, 42);
    doc.rect(14, y, 182, 8, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.text('Réf / Désignation Article', 18, y + 5.5);
    doc.text('Qté', 115, y + 5.5);
    doc.text('Prix Unit.', 140, y + 5.5);
    doc.text('Total HT', 172, y + 5.5);

    y += 12;
    doc.setTextColor(30, 41, 59);
    doc.setFont('helvetica', 'normal');

    inv.items.forEach((item, idx) => {
      if (idx % 2 === 1) {
        doc.setFillColor(248, 250, 252);
        doc.rect(14, y - 5, 182, 8, 'F');
      }
      doc.text(item.productName, 18, y);
      doc.text(`${item.quantity} ${item.unit}`, 115, y);
      doc.text(`${item.unitPrice.toLocaleString()} ${companySettings.currencySymbol}`, 140, y);
      doc.text(`${item.subtotal.toLocaleString()} ${companySettings.currencySymbol}`, 172, y);
      y += 8;
    });

    // Totals
    y += 6;
    doc.setDrawColor(226, 232, 240);
    doc.line(14, y, 196, y);
    y += 8;

    doc.setFont('helvetica', 'normal');
    doc.text(`Sous-total HT :`, 125, y);
    doc.text(`${inv.subtotal.toLocaleString()} ${companySettings.currencySymbol}`, 172, y);
    y += 6;

    doc.text(`TVA (${companySettings.defaultVatRate}%) :`, 125, y);
    doc.text(`${inv.vatAmount.toLocaleString()} ${companySettings.currencySymbol}`, 172, y);
    y += 8;

    doc.setFillColor(238, 242, 255);
    doc.rect(122, y - 5, 74, 9, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(49, 46, 129);
    doc.text(`TOTAL FACTURE :`, 125, y + 1);
    doc.text(`${inv.totalAmount.toLocaleString()} ${companySettings.currencySymbol}`, 170, y + 1);

    y += 12;
    doc.setFontSize(8);
    doc.setTextColor(16, 185, 129);
    doc.text(`Montant Encaissé : ${inv.paidAmount.toLocaleString()} ${companySettings.currencySymbol}`, 125, y);

    if (inv.remainingAmount > 0) {
      y += 6;
      doc.setTextColor(225, 29, 72);
      doc.setFont('helvetica', 'bold');
      doc.text(`Solde Dû Restant : ${inv.remainingAmount.toLocaleString()} ${companySettings.currencySymbol}`, 125, y);
    }

    // Footer
    y += 20;
    doc.setTextColor(148, 163, 184);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.text(`Merci pour votre confiance. Facture émise par le système ${companySettings.name}.`, 105, y, { align: 'center' });

    // Save
    doc.save(`Facture_${inv.invoiceNumber}.pdf`);
  };

  // WhatsApp Share
  const handleShareWhatsApp = (inv: Invoice) => {
    const text = `Bonjour ${inv.customerName}, voici le récapitulatif de votre facture N° *${inv.invoiceNumber}* émise par ${companySettings.name}.\n\n` +
      `• Montant Total: *${inv.totalAmount.toLocaleString()} CFA*\n` +
      `• Montant Payé: *${inv.paidAmount.toLocaleString()} CFA*\n` +
      `• Solde Restant: *${inv.remainingAmount.toLocaleString()} CFA*\n` +
      `• Statut: *${inv.status === 'paid' ? 'Soldée' : inv.status === 'partial' ? 'Paiement partiel' : 'Non payée'}*\n\n` +
      `Merci pour votre confiance !`;
    const cleanPhone = inv.customerPhone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  // Submit Payment
  const handleAddPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentInvoice || paymentAmount <= 0) return;

    addPaymentToInvoice(paymentInvoice.id, paymentAmount, paymentMethod, paymentNotes);
    showToast(`Paiement de ${paymentAmount.toLocaleString()} CFA enregistré pour la facture ${paymentInvoice.invoiceNumber}`);
    setPaymentInvoice(null);
    setPaymentAmount(0);
    setPaymentNotes('');
  };

  // Open Edit Invoice Modal
  const handleOpenEdit = (inv: Invoice) => {
    if (!isAdmin) {
      alert("Action réservée : Seul l'administrateur est autorisé à modifier une facture.");
      return;
    }
    setEditingInvoice(inv);
    setEditItems(inv.items.map(it => ({ ...it })));
    setEditCustomerId(inv.customerId || '');
    setEditCustomerName(inv.customerName);
    setEditCustomerPhone(inv.customerPhone);
    setEditSaleType(inv.saleType);
    setEditDate(inv.date);
    setEditDueDate(inv.dueDate || inv.date);
    setEditPaymentMethod(inv.paymentMethod);
    setEditPaidAmount(inv.paidAmount);
    setEditDiscountAmount(inv.discountAmount || 0);
    setEditNotes(inv.notes || '');
    setEditStoreName(inv.storeName || '');
    setEditAdjustStock(true);
    setSelectedProductToAdd('');
    setEditProductSearch('');
  };

  // Change customer in Edit Modal
  const handleCustomerSelectInEdit = (customerId: string) => {
    setEditCustomerId(customerId);
    const found = customers.find(c => c.id === customerId);
    if (found) {
      setEditCustomerName(found.name);
      setEditCustomerPhone(found.phone);
    }
  };

  // Switch Sale Type in Edit Modal
  const handleSaleTypeChangeInEdit = (newType: SaleType) => {
    setEditSaleType(newType);
    setEditItems(prev =>
      prev.map(item => {
        const prod = products.find(p => p.id === item.productId);
        const newUnitPrice = prod
          ? (newType === 'wholesale' ? prod.wholesalePrice : prod.retailPrice)
          : item.unitPrice;
        const subtotal = Math.round(item.quantity * newUnitPrice * (1 - (item.discount || 0) / 100));
        return {
          ...item,
          unitPrice: newUnitPrice,
          subtotal,
          total: subtotal
        };
      })
    );
  };

  // Add Product to Edit Modal Items
  const handleAddProductToEdit = (productId: string) => {
    if (!productId) return;
    const prod = products.find(p => p.id === productId);
    if (!prod) return;

    const existingIdx = editItems.findIndex(it => it.productId === productId);
    if (existingIdx !== -1) {
      setEditItems(prev => {
        const next = [...prev];
        const it = next[existingIdx];
        const newQty = it.quantity + 1;
        const subtotal = Math.round(newQty * it.unitPrice * (1 - (it.discount || 0) / 100));
        next[existingIdx] = {
          ...it,
          quantity: newQty,
          subtotal,
          total: subtotal
        };
        return next;
      });
    } else {
      const unitPrice = editSaleType === 'wholesale' ? prod.wholesalePrice : prod.retailPrice;
      const newItem: InvoiceItem = {
        id: 'item-' + Date.now() + Math.random().toString(36).substr(2, 4),
        productId: prod.id,
        productCode: prod.code,
        productName: prod.name,
        unit: prod.unit,
        quantity: 1,
        unitPrice,
        vatRate: prod.vatRate || 0,
        discount: 0,
        subtotal: unitPrice,
        total: unitPrice,
      };
      setEditItems(prev => [...prev, newItem]);
    }
    setSelectedProductToAdd('');
  };

  // Update specific item in Edit Modal
  const handleUpdateEditItem = (index: number, field: 'quantity' | 'unitPrice' | 'discount', value: number) => {
    setEditItems(prev => {
      const next = [...prev];
      const item = { ...next[index] };
      if (field === 'quantity') item.quantity = Math.max(1, value);
      if (field === 'unitPrice') item.unitPrice = Math.max(0, value);
      if (field === 'discount') item.discount = Math.min(100, Math.max(0, value));

      const lineTotal = item.quantity * item.unitPrice * (1 - (item.discount || 0) / 100);
      item.subtotal = Math.round(lineTotal);
      item.total = Math.round(lineTotal);
      next[index] = item;
      return next;
    });
  };

  // Remove item in Edit Modal
  const handleRemoveEditItem = (index: number) => {
    setEditItems(prev => prev.filter((_, idx) => idx !== index));
  };

  // Calculated totals in Edit Modal
  const editSubtotal = editItems.reduce((sum, it) => sum + (it.subtotal || it.total || 0), 0);
  const editVatAmount = Math.round((editSubtotal * (companySettings.defaultVatRate || 0)) / 100);
  const editTotalAmount = Math.max(0, Math.round(editSubtotal + editVatAmount - editDiscountAmount));
  const editRemainingAmount = Math.max(0, editTotalAmount - editPaidAmount);

  // Save Edit Invoice
  const handleSaveEditInvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice) return;
    if (editItems.length === 0) {
      alert("Veuillez ajouter au moins un article à la facture.");
      return;
    }
    if (!editCustomerName.trim()) {
      alert("Veuillez renseigner le nom du client.");
      return;
    }

    const status: 'paid' | 'partial' | 'unpaid' =
      editRemainingAmount === 0 ? 'paid' : editPaidAmount > 0 ? 'partial' : 'unpaid';

    updateInvoice(
      editingInvoice.id,
      {
        date: editDate,
        dueDate: editDueDate,
        customerId: editCustomerId || 'cust-particulier',
        customerName: editCustomerName.trim(),
        customerPhone: editCustomerPhone.trim(),
        saleType: editSaleType,
        items: editItems,
        subtotal: editSubtotal,
        vatAmount: editVatAmount,
        discountAmount: editDiscountAmount,
        totalAmount: editTotalAmount,
        paidAmount: editPaidAmount,
        remainingAmount: editRemainingAmount,
        status,
        paymentMethod: editPaymentMethod,
        notes: editNotes,
        storeName: editStoreName || editingInvoice.storeName,
      },
      {
        adjustStock: editAdjustStock
      }
    );

    showToast(`Facture ${editingInvoice.invoiceNumber} mise à jour avec succès !`);
    setEditingInvoice(null);
  };

  // Open Delete Confirmation Modal
  const handleOpenDelete = (inv: Invoice) => {
    if (!isAdmin) {
      alert("Action réservée : Seul l'administrateur est autorisé à supprimer une facture.");
      return;
    }
    setDeletingInvoice(inv);
    setDeleteRestoreStock(true);
  };

  // Confirm Delete Invoice
  const handleConfirmDelete = () => {
    if (!deletingInvoice || !isAdmin) return;
    const invNum = deletingInvoice.invoiceNumber;
    deleteInvoice(deletingInvoice.id, { restoreStock: deleteRestoreStock });
    showToast(`Facture ${invNum} supprimée définitivement.`);
    setDeletingInvoice(null);
    if (selectedInvoice?.id === deletingInvoice.id) {
      setSelectedInvoice(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl border border-slate-700 animate-in fade-in slide-in-from-bottom-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-slate-400 hover:text-white ml-2">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-bold">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Gestion des Factures Vente & Règlements
            </h2>
            <p className="text-xs text-slate-500">
              Modifiez, supprimez, imprimez, partagez par WhatsApp et encaissez vos factures en temps réel sur tous vos appareils.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {isAdmin ? (
            <span className="px-3 py-1.5 text-xs font-bold rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800/60 flex items-center gap-1.5 shadow-2xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Session Admin : Modifications & Suppressions activées</span>
            </span>
          ) : (
            <span className="px-3 py-1.5 text-xs font-medium rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800/60 flex items-center gap-1.5 shadow-2xs">
              <Lock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              <span>Consultation ({currentUser?.name}) : Modifications réservées à l'Admin</span>
            </span>
          )}

          <button
            onClick={handleExportExcel}
            className="px-3 py-2 text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 border border-emerald-200 dark:border-emerald-800/60 rounded-xl transition-colors flex items-center gap-1.5 shrink-0 self-start sm:self-auto"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Export Excel</span>
          </button>
        </div>
      </div>

      {/* Exact Invoices Counters Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-[11px] font-medium text-slate-500">Factures Enregistrées</span>
          <p className="text-lg font-black text-slate-900 dark:text-white mt-0.5">{invoices.length}</p>
          <span className="text-[10px] text-slate-400">Nombre exact enregistré</span>
        </div>
        <div className="p-3 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-xl border border-emerald-200/80 dark:border-emerald-900/40 shadow-2xs">
          <span className="text-[11px] font-medium text-emerald-700 dark:text-emerald-400">Factures Réglées</span>
          <p className="text-lg font-black text-emerald-800 dark:text-emerald-300 mt-0.5">{invoices.filter(i => i.status === 'paid').length}</p>
          <span className="text-[10px] text-emerald-600">Paiement intégral reçu</span>
        </div>
        <div className="p-3 bg-amber-50/60 dark:bg-amber-950/30 rounded-xl border border-amber-200/80 dark:border-amber-900/40 shadow-2xs">
          <span className="text-[11px] font-medium text-amber-700 dark:text-amber-400">Paiements Partiels</span>
          <p className="text-lg font-black text-amber-800 dark:text-amber-300 mt-0.5">{invoices.filter(i => i.status === 'partial').length}</p>
          <span className="text-[10px] text-amber-600">Acomptes enregistrés</span>
        </div>
        <div className="p-3 bg-rose-50/60 dark:bg-rose-950/30 rounded-xl border border-rose-200/80 dark:border-rose-900/40 shadow-2xs">
          <span className="text-[11px] font-medium text-rose-700 dark:text-rose-400">Factures avec Reste</span>
          <p className="text-lg font-black text-rose-800 dark:text-rose-300 mt-0.5">{invoices.filter(i => i.remainingAmount > 0).length}</p>
          <span className="text-[10px] text-rose-600 font-bold">{invoices.filter(i => i.remainingAmount > 0).reduce((sum, i) => sum + i.remainingAmount, 0).toLocaleString()} CFA restants</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
        {/* Search */}
        <div className="relative sm:col-span-2">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Rechercher par N° facture, nom de client, caissier..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
          />
        </div>

        {/* User Filter */}
        <div className="flex items-center gap-1.5 bg-white dark:bg-slate-800 px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-xl">
          <UserIcon className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
          <select
            value={userFilter}
            onChange={e => setUserFilter(e.target.value)}
            className="w-full text-xs font-semibold bg-transparent text-slate-800 dark:text-slate-200 outline-none cursor-pointer"
          >
            <option value="all">👥 Tous les émetteurs / Caisses</option>
            {users.map(u => (
              <option key={u.id} value={u.name}>
                👤 {u.name} ({u.role.toUpperCase()})
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1 bg-white dark:bg-slate-800 p-1 border border-slate-200 dark:border-slate-700 rounded-xl">
          <button
            onClick={() => setStatusFilter('all')}
            className={`flex-1 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
              statusFilter === 'all' ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Toutes
          </button>
          <button
            onClick={() => setStatusFilter('paid')}
            className={`flex-1 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
              statusFilter === 'paid' ? 'bg-emerald-600 text-white' : 'text-emerald-600 dark:text-emerald-400'
            }`}
          >
            Payées
          </button>
          <button
            onClick={() => setStatusFilter('partial')}
            className={`flex-1 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
              statusFilter === 'partial' ? 'bg-amber-500 text-white' : 'text-amber-600 dark:text-amber-400'
            }`}
          >
            Partielles
          </button>
          <button
            onClick={() => setStatusFilter('unpaid')}
            className={`flex-1 py-1 text-[11px] font-semibold rounded-lg transition-colors ${
              statusFilter === 'unpaid' ? 'bg-rose-600 text-white' : 'text-rose-600 dark:text-rose-400'
            }`}
          >
            Impayées
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* MOBILE / TABLET CARD VIEW (Visible on small & medium screens) */}
      {/* ========================================================================= */}
      <div className="block lg:hidden space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-slate-400 text-xs bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
            Aucune facture trouvée pour ces critères de recherche.
          </div>
        ) : (
          filtered.map(inv => (
            <div
              key={inv.id}
              className="p-4 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs space-y-3"
            >
              {/* Top Row: Invoice Number, Badges & Date */}
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-black text-sm text-slate-900 dark:text-white">
                      {inv.invoiceNumber}
                    </span>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${
                        inv.saleType === 'wholesale'
                          ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                          : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                      }`}
                    >
                      {inv.saleType === 'wholesale' ? 'GROS' : 'DÉTAIL'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5">Date : {inv.date}</p>
                </div>

                <div>
                  {inv.status === 'paid' ? (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400 flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      <span>Payée</span>
                    </span>
                  ) : inv.status === 'partial' ? (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>Partielle</span>
                    </span>
                  ) : (
                    <span className="px-2.5 py-1 text-[10px] font-bold rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400 flex items-center gap-1">
                      <AlertCircle className="w-3 h-3" />
                      <span>Impayée</span>
                    </span>
                  )}
                </div>
              </div>

              {/* Customer Info */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-700/60 flex justify-between items-center text-xs">
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">{inv.customerName}</p>
                  <p className="text-[11px] text-slate-500 font-mono">{inv.customerPhone}</p>
                </div>
                <div className="text-right text-[11px] text-slate-400">
                  <p>Établi par : <strong className="text-slate-700 dark:text-slate-300">{inv.createdBy}</strong></p>
                  <p>{inv.items.reduce((s, it) => s + it.quantity, 0)} article(s)</p>
                </div>
              </div>

              {/* Amounts Grid */}
              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-slate-100/70 dark:bg-slate-750/50">
                  <p className="text-[10px] text-slate-500 font-medium">Total</p>
                  <p className="font-black text-slate-900 dark:text-white mt-0.5 text-xs">
                    {inv.totalAmount.toLocaleString()} CFA
                  </p>
                </div>
                <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300">
                  <p className="text-[10px] font-medium">Payé</p>
                  <p className="font-black mt-0.5 text-xs">
                    {inv.paidAmount.toLocaleString()} CFA
                  </p>
                </div>
                <div className={`p-2 rounded-xl ${inv.remainingAmount > 0 ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300' : 'bg-slate-100/70 dark:bg-slate-750/50 text-slate-600'}`}>
                  <p className="text-[10px] font-medium">Solde Dû</p>
                  <p className="font-black mt-0.5 text-xs">
                    {inv.remainingAmount.toLocaleString()} CFA
                  </p>
                </div>
              </div>

              {/* Action Buttons for Mobile */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60 flex flex-wrap items-center gap-1.5 justify-between">
                {isAdmin ? (
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {/* Modifier Button */}
                    <button
                      onClick={() => handleOpenEdit(inv)}
                      className="px-2.5 py-1.5 text-xs font-bold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 border border-amber-200 dark:border-amber-800/60 rounded-xl flex items-center gap-1 transition-colors"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Modifier</span>
                    </button>

                    {/* Supprimer Button */}
                    <button
                      onClick={() => handleOpenDelete(inv)}
                      className="px-2.5 py-1.5 text-xs font-bold bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100 border border-rose-200 dark:border-rose-800/60 rounded-xl flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Supprimer</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 px-2.5 py-1 bg-slate-100 dark:bg-slate-700/60 text-slate-500 dark:text-slate-400 rounded-xl text-[11px] font-medium border border-slate-200/60 dark:border-slate-700">
                    <Lock className="w-3 h-3 text-slate-400" />
                    <span>Lecture seule (Admin requis)</span>
                  </div>
                )}

                <div className="flex items-center gap-1">
                  {/* View Details / Print */}
                  <button
                    onClick={() => setSelectedInvoice(inv)}
                    className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-indigo-600 bg-slate-100 dark:bg-slate-700 rounded-xl transition-colors"
                    title="Voir & Imprimer"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  {/* Export PDF */}
                  <button
                    onClick={() => handleExportPDF(inv)}
                    className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-blue-600 bg-slate-100 dark:bg-slate-700 rounded-xl transition-colors"
                    title="Télécharger PDF"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  {/* WhatsApp */}
                  <button
                    onClick={() => handleShareWhatsApp(inv)}
                    className="p-1.5 text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50 rounded-xl transition-colors"
                    title="Partager WhatsApp"
                  >
                    <Send className="w-4 h-4" />
                  </button>

                  {/* Pay Remaining */}
                  {inv.remainingAmount > 0 && (
                    <button
                      onClick={() => {
                        setPaymentInvoice(inv);
                        setPaymentAmount(inv.remainingAmount);
                        setPaymentNotes(`Règlement solde facture ${inv.invoiceNumber}`);
                      }}
                      className="px-2.5 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-2xs transition-colors"
                    >
                      Régler
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* ========================================================================= */}
      {/* DESKTOP INVOICES TABLE (Visible on larger screens) */}
      {/* ========================================================================= */}
      <div className="hidden lg:block bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-900/80 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider border-b border-slate-200 dark:border-slate-700">
              <tr>
                <th className="py-3.5 px-4">N° Facture</th>
                <th className="py-3.5 px-4">Date</th>
                <th className="py-3.5 px-4">Client</th>
                <th className="py-3.5 px-4">Type Vente</th>
                <th className="py-3.5 px-4 text-right">Montant Total</th>
                <th className="py-3.5 px-4 text-right">Montant Payé</th>
                <th className="py-3.5 px-4 text-right">Solde Dû</th>
                <th className="py-3.5 px-4 text-center">Statut</th>
                <th className="py-3.5 px-4 text-center bg-slate-100/80 dark:bg-slate-850">Actions Gestion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-400 text-xs">
                    Aucune facture trouvée pour ces critères de recherche.
                  </td>
                </tr>
              ) : (
                filtered.map(inv => (
                  <tr key={inv.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-750/50 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3.5 px-4 whitespace-nowrap">{inv.date}</td>
                    <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-200">
                      <p>{inv.customerName}</p>
                      <p className="text-[10px] text-slate-400 font-mono">{inv.customerPhone}</p>
                    </td>
                    <td className="py-3.5 px-4">
                      <span className={`px-2 py-0.5 text-[10px] font-bold rounded-md ${inv.saleType === 'wholesale' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'}`}>
                        {inv.saleType === 'wholesale' ? 'GROS' : 'DÉTAIL'}
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-slate-900 dark:text-white">
                      {inv.totalAmount.toLocaleString()} CFA
                    </td>
                    <td className="py-3.5 px-4 text-right font-semibold text-emerald-600 dark:text-emerald-400">
                      {inv.paidAmount.toLocaleString()} CFA
                    </td>
                    <td className="py-3.5 px-4 text-right font-bold text-rose-600 dark:text-rose-400">
                      {inv.remainingAmount.toLocaleString()} CFA
                    </td>
                    <td className="py-3.5 px-4 text-center">
                      {inv.status === 'paid' ? (
                        <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400">
                          Payée
                        </span>
                      ) : inv.status === 'partial' ? (
                        <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400">
                          Partielle
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400">
                          Non Payée
                        </span>
                      )}
                    </td>
                    <td className="py-3.5 px-4 text-center bg-slate-50/50 dark:bg-slate-900/30">
                      <div className="flex items-center justify-center gap-1.5">
                        {/* Modifier & Supprimer (Admin Only) */}
                        {isAdmin ? (
                          <>
                            <button
                              onClick={() => handleOpenEdit(inv)}
                              className="px-2 py-1 text-xs font-bold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 hover:bg-amber-100 border border-amber-200 dark:border-amber-800/60 rounded-lg flex items-center gap-1 transition-colors"
                              title="Modifier la facture"
                            >
                              <Edit className="w-3.5 h-3.5" />
                              <span>Modifier</span>
                            </button>

                            <button
                              onClick={() => handleOpenDelete(inv)}
                              className="px-2 py-1 text-xs font-bold bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 hover:bg-rose-100 border border-rose-200 dark:border-rose-800/60 rounded-lg flex items-center gap-1 transition-colors"
                              title="Supprimer la facture"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Supprimer</span>
                            </button>
                          </>
                        ) : (
                          <span className="px-2 py-0.5 text-[10px] font-medium text-slate-400 bg-slate-100 dark:bg-slate-800 rounded inline-flex items-center gap-1 border border-slate-200/50 dark:border-slate-700">
                            <Lock className="w-3 h-3 text-slate-400" />
                            Lecture seule
                          </span>
                        )}

                        {/* View & Print */}
                        <button
                          onClick={() => setSelectedInvoice(inv)}
                          className="p-1.5 text-slate-500 hover:text-indigo-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                          title="Visualiser & Imprimer la facture"
                        >
                          <Eye className="w-4 h-4" />
                        </button>

                        {/* Download PDF */}
                        <button
                          onClick={() => handleExportPDF(inv)}
                          className="p-1.5 text-slate-500 hover:text-blue-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                          title="Télécharger PDF"
                        >
                          <Download className="w-4 h-4" />
                        </button>

                        {/* WhatsApp */}
                        <button
                          onClick={() => handleShareWhatsApp(inv)}
                          className="p-1.5 text-slate-500 hover:text-emerald-600 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                          title="Relancer via WhatsApp"
                        >
                          <Send className="w-4 h-4 text-emerald-600" />
                        </button>

                        {/* Pay Remaining */}
                        {inv.remainingAmount > 0 && (
                          <button
                            onClick={() => {
                              setPaymentInvoice(inv);
                              setPaymentAmount(inv.remainingAmount);
                              setPaymentNotes(`Règlement solde facture ${inv.invoiceNumber}`);
                            }}
                            className="px-2 py-1 text-[10px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg shadow-2xs transition-colors"
                            title="Enregistrer un versement"
                          >
                            Régler
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. EDIT INVOICE MODAL */}
      {/* ========================================================================= */}
      {editingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in my-6 max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between p-4 bg-slate-900 text-white shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Edit className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">
                    Modification de la Facture #{editingInvoice.invoiceNumber}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Ajustez les articles, quantités, tarifs, client ou encaissements.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingInvoice(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveEditInvoice} className="flex-1 overflow-y-auto p-5 space-y-5 text-xs">
              {/* Row 1: General Info */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
                {/* Client selection or custom name */}
                <div className="md:col-span-2 space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Client Associé
                  </label>
                  <div className="flex gap-2">
                    <select
                      value={editCustomerId}
                      onChange={e => handleCustomerSelectInEdit(e.target.value)}
                      className="flex-1 px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl outline-none text-slate-900 dark:text-white font-medium"
                    >
                      <option value="">-- Client Personnalisé / Comptoir --</option>
                      {customers.map(c => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.phone})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <input
                      type="text"
                      placeholder="Nom du Client"
                      value={editCustomerName}
                      onChange={e => setEditCustomerName(e.target.value)}
                      required
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Téléphone Client"
                      value={editCustomerPhone}
                      onChange={e => setEditCustomerPhone(e.target.value)}
                      className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                </div>

                {/* Sale Type (Wholesale vs Retail) */}
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 dark:text-slate-300">
                    Type de Vente & Tarif
                  </label>
                  <div className="flex rounded-xl overflow-hidden border border-slate-200 dark:border-slate-700 p-0.5 bg-white dark:bg-slate-800">
                    <button
                      type="button"
                      onClick={() => handleSaleTypeChangeInEdit('retail')}
                      className={`flex-1 py-1.5 text-center font-bold rounded-lg transition-colors ${
                        editSaleType === 'retail'
                          ? 'bg-emerald-600 text-white'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      Détail
                    </button>
                    <button
                      type="button"
                      onClick={() => handleSaleTypeChangeInEdit('wholesale')}
                      className={`flex-1 py-1.5 text-center font-bold rounded-lg transition-colors ${
                        editSaleType === 'wholesale'
                          ? 'bg-indigo-600 text-white'
                          : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'
                      }`}
                    >
                      En Gros
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1">
                    Bascule automatiquement les prix unitaires des articles.
                  </p>
                </div>

                {/* Dates */}
                <div className="space-y-2">
                  <div>
                    <label className="font-bold text-slate-700 dark:text-slate-300">Date d'Émission</label>
                    <input
                      type="date"
                      value={editDate}
                      onChange={e => setEditDate(e.target.value)}
                      required
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-slate-700 dark:text-slate-300">Date d'Échéance</label>
                    <input
                      type="date"
                      value={editDueDate}
                      onChange={e => setEditDueDate(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Row 2: Add Products / Articles */}
              <div className="space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Package className="w-4 h-4 text-indigo-500" />
                    <span>Articles et Lignes de Facture ({editItems.length})</span>
                  </h4>

                  {/* Add Product Dropdown */}
                  <div className="flex items-center gap-2">
                    <select
                      value={selectedProductToAdd}
                      onChange={e => {
                        const val = e.target.value;
                        setSelectedProductToAdd(val);
                        if (val) handleAddProductToEdit(val);
                      }}
                      className="px-3 py-1.5 text-xs bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 text-indigo-900 dark:text-indigo-200 rounded-xl outline-none font-semibold cursor-pointer"
                    >
                      <option value="">➕ Ajouter un produit du catalogue...</option>
                      {products.map(p => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({p.code}) — Stock: {p.currentStock} {p.unit}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Items Table */}
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400 font-bold uppercase">
                      <tr>
                        <th className="p-2.5">Article / Réf</th>
                        <th className="p-2.5 text-center w-28">Quantité</th>
                        <th className="p-2.5 text-right w-32">Prix Unit. (CFA)</th>
                        <th className="p-2.5 text-center w-24">Remise (%)</th>
                        <th className="p-2.5 text-right w-32">Total Ligne</th>
                        <th className="p-2.5 text-center w-12">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-700 bg-white dark:bg-slate-800">
                      {editItems.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-6 text-center text-slate-400">
                            Aucun article dans cette facture. Ajoutez un produit ci-dessus.
                          </td>
                        </tr>
                      ) : (
                        editItems.map((item, idx) => {
                          const prod = products.find(p => p.id === item.productId);
                          return (
                            <tr key={idx} className="hover:bg-slate-50/60 dark:hover:bg-slate-750/30">
                              <td className="p-2.5">
                                <p className="font-bold text-slate-900 dark:text-white">{item.productName}</p>
                                <p className="text-[10px] text-slate-400 font-mono">
                                  {item.productCode} • Unité : {item.unit}
                                  {prod && (
                                    <span className="ml-2 text-slate-500 font-medium">
                                      (Stock dispo: {prod.currentStock})
                                    </span>
                                  )}
                                </p>
                              </td>
                              <td className="p-2.5">
                                <div className="flex items-center justify-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleUpdateEditItem(idx, 'quantity', item.quantity - 1)}
                                    className="p-1 rounded bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <input
                                    type="number"
                                    min="1"
                                    value={item.quantity}
                                    onChange={e => handleUpdateEditItem(idx, 'quantity', Number(e.target.value))}
                                    className="w-12 text-center py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded font-bold text-slate-900 dark:text-white outline-none"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleUpdateEditItem(idx, 'quantity', item.quantity + 1)}
                                    className="p-1 rounded bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-700 dark:text-slate-300"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>
                              </td>
                              <td className="p-2.5 text-right">
                                <input
                                  type="number"
                                  min="0"
                                  value={item.unitPrice}
                                  onChange={e => handleUpdateEditItem(idx, 'unitPrice', Number(e.target.value))}
                                  className="w-28 text-right py-1 px-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded font-semibold text-slate-900 dark:text-white outline-none"
                                />
                              </td>
                              <td className="p-2.5 text-center">
                                <input
                                  type="number"
                                  min="0"
                                  max="100"
                                  value={item.discount || 0}
                                  onChange={e => handleUpdateEditItem(idx, 'discount', Number(e.target.value))}
                                  className="w-16 text-center py-1 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-slate-900 dark:text-white outline-none"
                                />
                              </td>
                              <td className="p-2.5 text-right font-bold text-slate-900 dark:text-white">
                                {item.subtotal.toLocaleString()} CFA
                              </td>
                              <td className="p-2.5 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleRemoveEditItem(idx)}
                                  className="p-1 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 dark:hover:bg-rose-950/40"
                                  title="Retirer cet article"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Row 3: Totals, Payments, Notes & Stock Option */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                {/* Payment & Settings column */}
                <div className="space-y-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700">
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <DollarSign className="w-4 h-4 text-emerald-500" />
                    <span>Règlement & Encaissement</span>
                  </h4>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-medium mb-1">
                        Montant Déjà Encaissé (CFA)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max={editTotalAmount}
                        value={editPaidAmount}
                        onChange={e => setEditPaidAmount(Number(e.target.value))}
                        className="w-full px-3 py-1.5 font-bold text-emerald-600 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-medium mb-1">
                        Mode de Paiement
                      </label>
                      <select
                        value={editPaymentMethod}
                        onChange={e => setEditPaymentMethod(e.target.value as PaymentMethod)}
                        className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                      >
                        <option value="cash">Espèces</option>
                        <option value="mobile_money">Wave / Orange Money</option>
                        <option value="check">Chèque</option>
                        <option value="transfer">Virement Bancaire</option>
                        <option value="card">Carte Bancaire</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-medium mb-1">
                      Remise Globale Additionnelle (CFA)
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={editDiscountAmount}
                      onChange={e => setEditDiscountAmount(Number(e.target.value))}
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-400 font-medium mb-1">
                      Notes / Observations sur la Facture
                    </label>
                    <textarea
                      rows={2}
                      value={editNotes}
                      onChange={e => setEditNotes(e.target.value)}
                      placeholder="Commentaires, conditions particulières..."
                      className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white resize-none"
                    />
                  </div>

                  {/* Stock adjustment toggle */}
                  <label className="flex items-center gap-2 pt-1 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={editAdjustStock}
                      onChange={e => setEditAdjustStock(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 border-slate-300"
                    />
                    <span className="font-semibold text-slate-700 dark:text-slate-300 text-[11px]">
                      Ajuster automatiquement les stocks des articles modifiés
                    </span>
                  </label>
                </div>

                {/* Summary Totals column */}
                <div className="p-4 rounded-xl bg-indigo-50/50 dark:bg-slate-900/80 border border-indigo-100 dark:border-slate-700 space-y-3 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-indigo-950 dark:text-white mb-3">
                      Récapitulatif Financier Révisé
                    </h4>

                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between text-slate-600 dark:text-slate-400">
                        <span>Sous-total HT :</span>
                        <span className="font-bold">{editSubtotal.toLocaleString()} CFA</span>
                      </div>
                      <div className="flex justify-between text-slate-600 dark:text-slate-400">
                        <span>TVA ({companySettings.defaultVatRate || 0}%) :</span>
                        <span>{editVatAmount.toLocaleString()} CFA</span>
                      </div>
                      {editDiscountAmount > 0 && (
                        <div className="flex justify-between text-rose-600 font-semibold">
                          <span>Remise Globale :</span>
                          <span>-{editDiscountAmount.toLocaleString()} CFA</span>
                        </div>
                      )}
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-700 flex justify-between text-sm font-black text-indigo-950 dark:text-white">
                        <span>NOUVEAU TOTAL TTC :</span>
                        <span className="text-indigo-600 dark:text-indigo-400">
                          {editTotalAmount.toLocaleString()} CFA
                        </span>
                      </div>
                      <div className="flex justify-between text-emerald-600 font-bold">
                        <span>Montant Encaissé :</span>
                        <span>{editPaidAmount.toLocaleString()} CFA</span>
                      </div>
                      <div className={`p-2 rounded-xl border flex justify-between font-bold ${
                        editRemainingAmount === 0
                          ? 'bg-emerald-100/60 border-emerald-200 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300'
                          : 'bg-rose-100/60 border-rose-200 text-rose-800 dark:bg-rose-950/40 dark:text-rose-300'
                      }`}>
                        <span>Solde Restant Dû :</span>
                        <span>{editRemainingAmount.toLocaleString()} CFA</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 text-[10px] text-slate-400">
                    Statut automatique :{' '}
                    <strong className="text-slate-700 dark:text-slate-300 uppercase">
                      {editRemainingAmount === 0 ? 'Payée' : editPaidAmount > 0 ? 'Partielle' : 'Impayée'}
                    </strong>
                  </div>
                </div>
              </div>

              {/* Modal Actions Footer */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-700 flex items-center justify-between shrink-0">
                <button
                  type="button"
                  onClick={() => setEditingInvoice(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md flex items-center gap-1.5 transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Enregistrer les Modifications</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. DELETE INVOICE CONFIRMATION MODAL */}
      {/* ========================================================================= */}
      {deletingInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in">
            <div className="p-5 bg-rose-600 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-sm">Confirmation de Suppression</h3>
                  <p className="text-[11px] text-rose-100">Facture #{deletingInvoice.invoiceNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setDeletingInvoice(null)}
                className="text-rose-100 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-300 space-y-1">
                <p className="font-bold">Êtes-vous sûr de vouloir supprimer définitivement cette facture ?</p>
                <p className="text-[11px]">
                  Cette opération est irréversible. Les créances associées et historiques seront mis à jour.
                </p>
              </div>

              {/* Invoice Quick Summary */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-500">Client :</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">{deletingInvoice.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date d'émission :</span>
                  <span className="font-medium text-slate-800 dark:text-slate-200">{deletingInvoice.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Montant Total :</span>
                  <span className="font-bold text-slate-900 dark:text-white">{deletingInvoice.totalAmount.toLocaleString()} CFA</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Articles vendus :</span>
                  <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">
                    {deletingInvoice.items.reduce((s, it) => s + it.quantity, 0)} unité(s) ({deletingInvoice.items.length} références)
                  </span>
                </div>
              </div>

              {/* Stock restoration checkbox */}
              <label className="flex items-start gap-2.5 p-3 rounded-xl bg-slate-100 dark:bg-slate-750/50 border border-slate-200 dark:border-slate-700 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={deleteRestoreStock}
                  onChange={e => setDeleteRestoreStock(e.target.checked)}
                  className="w-4 h-4 mt-0.5 rounded text-rose-600 focus:ring-rose-500 border-slate-300"
                />
                <div>
                  <span className="font-bold text-slate-800 dark:text-slate-200 block">
                    Réintégrer automatiquement les stocks
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block mt-0.5">
                    Remet les {deletingInvoice.items.reduce((s, it) => s + it.quantity, 0)} articles vendus dans l'inventaire des produits disponibles.
                  </span>
                </div>
              </label>

              {/* Buttons */}
              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDeletingInvoice(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="px-4 py-2 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl shadow-md flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Confirmer la Suppression</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. DETAIL / PRINT MODAL */}
      {/* ========================================================================= */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in my-8">
            <div className="flex flex-wrap items-center justify-between p-4 bg-slate-900 text-white print:hidden gap-2">
              <h3 className="font-bold text-sm">Facture Officielle #{selectedInvoice.invoiceNumber}</h3>
              <div className="flex items-center gap-2 flex-wrap">
                {/* Modifier & Supprimer buttons inside details (Admin Only) */}
                {isAdmin && (
                  <>
                    <button
                      onClick={() => {
                        handleOpenEdit(selectedInvoice);
                        setSelectedInvoice(null);
                      }}
                      className="px-3 py-1.5 text-xs font-bold bg-amber-500 hover:bg-amber-600 text-white rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Modifier</span>
                    </button>

                    <button
                      onClick={() => {
                        handleOpenDelete(selectedInvoice);
                      }}
                      className="px-3 py-1.5 text-xs font-bold bg-rose-600 hover:bg-rose-700 text-white rounded-xl flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Supprimer</span>
                    </button>
                  </>
                )}

                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimer</span>
                </button>
                <button
                  onClick={() => handleExportPDF(selectedInvoice)}
                  className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>PDF</span>
                </button>
                <button onClick={() => setSelectedInvoice(null)} className="text-white hover:opacity-80 p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Printable Invoice Paper Container */}
            <div className="p-8 bg-white text-slate-900 space-y-6 text-xs print:p-0">
              {/* Top Company Header */}
              <div className="flex justify-between items-start border-b border-slate-200 pb-6">
                <div className="flex items-start gap-4">
                  {companySettings.logo ? (
                    <img
                      src={companySettings.logo}
                      alt="Logo Entreprise"
                      className="w-20 h-20 object-contain rounded-xl border border-slate-200 bg-slate-50 p-1.5 shadow-xs shrink-0"
                    />
                  ) : (
                    <div className="w-16 h-16 rounded-2xl bg-indigo-900 text-white font-black text-2xl flex items-center justify-center shadow-md shrink-0">
                      ERP
                    </div>
                  )}

                  <div>
                    <h1 className="text-2xl font-black text-indigo-950 uppercase tracking-tight">
                      {companySettings.name}
                    </h1>
                    <p className="text-slate-600 text-xs mt-1 font-medium">
                      {companySettings.address} — {companySettings.city}, {companySettings.country}
                    </p>
                    <p className="text-slate-500 text-xs mt-0.5">
                      Tél : <span className="font-bold text-slate-700">{companySettings.phone}</span> | Email : {companySettings.email}
                    </p>
                    <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400 font-mono">
                      <span>NIF : {companySettings.nif}</span>
                      <span>•</span>
                      <span>RCCM : {companySettings.rccm}</span>
                    </div>
                  </div>
                </div>

                <div className="text-right space-y-1">
                  <div className="inline-block px-3 py-1 bg-slate-900 text-white font-black text-xs rounded-lg uppercase tracking-wider font-mono">
                    FACTURE OFFICIELLE
                  </div>
                  <p className="font-mono font-black text-indigo-600 text-base">#{selectedInvoice.invoiceNumber}</p>
                  <p className="text-slate-500 text-xs">Date : <strong className="text-slate-800">{selectedInvoice.date}</strong></p>
                  <div>
                    <span className={`inline-flex items-center gap-1 mt-1.5 px-3 py-1 text-xs font-bold rounded-full uppercase shadow-2xs ${
                      selectedInvoice.status === 'paid'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                        : 'bg-rose-100 text-rose-800 border border-rose-200'
                    }`}>
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{selectedInvoice.status === 'paid' ? 'FACTURE PAYÉE' : 'SOLDE RESTANT DÛ'}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Customer Box */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">FACTURÉ À :</p>
                  <p className="font-black text-slate-900 text-sm mt-0.5">{selectedInvoice.customerName}</p>
                  <p className="text-slate-500 text-xs">Tél : {selectedInvoice.customerPhone}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] uppercase tracking-wider text-slate-400 font-bold">DÉTAILS DE VENTE :</p>
                  <p className="font-bold text-indigo-600 uppercase text-xs mt-0.5">
                    {selectedInvoice.saleType === 'wholesale' ? 'PRIX DE GROS' : 'PRIX AU DÉTAIL'}
                  </p>
                  <p className="text-slate-500 text-[11px]">Établi par : <span className="font-semibold">{selectedInvoice.createdBy || 'Administration'}</span></p>
                </div>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 rounded-xl overflow-hidden shadow-2xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-white font-bold">
                    <tr>
                      <th className="p-3">Article / Désignation</th>
                      <th className="p-3 text-center">Quantité</th>
                      <th className="p-3 text-right">Prix Unitaire</th>
                      <th className="p-3 text-right">Total HT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 bg-white">
                    {selectedInvoice.items.map((item, idx) => (
                      <tr key={idx} className={idx % 2 === 1 ? 'bg-slate-50/50' : ''}>
                        <td className="p-3">
                          <p className="font-bold text-slate-900">{item.productName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">Code: {item.productCode}</p>
                        </td>
                        <td className="p-3 text-center font-bold text-slate-700">
                          <span className="px-2 py-0.5 bg-slate-100 rounded-md font-mono">{item.quantity} {item.unit}</span>
                        </td>
                        <td className="p-3 text-right text-slate-600">{item.unitPrice.toLocaleString()} {companySettings.currencySymbol}</td>
                        <td className="p-3 text-right font-black text-slate-900">{item.subtotal.toLocaleString()} {companySettings.currencySymbol}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Totals Summary */}
              <div className="flex justify-between items-end pt-2">
                <div className="w-1/2 p-3 rounded-xl bg-slate-50 border border-slate-200/60 text-[11px] text-slate-500 space-y-1">
                  <p className="font-bold text-slate-700">Conditions de règlement :</p>
                  <p>• Paiement à réception ou selon accord commercial enregistré.</p>
                  <p>• Les marchandises vendues ne sont ni reprises ni échangées après 48h.</p>
                </div>

                <div className="w-64 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-600">
                    <span>Sous-total HT :</span>
                    <span className="font-bold">{selectedInvoice.subtotal.toLocaleString()} {companySettings.currencySymbol}</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>TVA ({companySettings.defaultVatRate}%) :</span>
                    <span>{selectedInvoice.vatAmount.toLocaleString()} {companySettings.currencySymbol}</span>
                  </div>
                  <div className="flex justify-between text-sm font-black text-indigo-950 p-2.5 bg-indigo-50 border border-indigo-100 rounded-xl">
                    <span>TOTAL FACTURE :</span>
                    <span className="text-indigo-600">{selectedInvoice.totalAmount.toLocaleString()} {companySettings.currencySymbol}</span>
                  </div>
                  <div className="flex justify-between text-emerald-600 font-bold px-1">
                    <span>Montant Encaissé :</span>
                    <span>{selectedInvoice.paidAmount.toLocaleString()} {companySettings.currencySymbol}</span>
                  </div>
                  {selectedInvoice.remainingAmount > 0 && (
                    <div className="flex justify-between text-rose-600 font-bold text-xs p-2 bg-rose-50 border border-rose-200 rounded-xl">
                      <span>Solde Restant Dû :</span>
                      <span>{selectedInvoice.remainingAmount.toLocaleString()} {companySettings.currencySymbol}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Stamp & Footer Legal */}
              <div className="pt-6 border-t border-slate-200 grid grid-cols-2 gap-4 items-end">
                <div className="text-[10px] text-slate-400 space-y-0.5">
                  <p className="font-bold text-slate-600">{companySettings.name}</p>
                  <p>Système de gestion commerciale {companySettings.name}</p>
                  <p className="font-mono">Document officiel certifié</p>
                </div>

                <div className="text-right">
                  <div className="inline-block w-40 h-16 border border-dashed border-slate-300 rounded-xl p-2 text-[10px] text-slate-400 text-center">
                    Cachet & Signature
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. PAYMENT DEPOSIT MODAL */}
      {/* ========================================================================= */}
      {paymentInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in">
            <div className="flex items-center justify-between p-4 bg-emerald-600 text-white">
              <h3 className="font-bold text-sm">Enregistrer un Règlement / Encaisser</h3>
              <button onClick={() => setPaymentInvoice(null)} className="text-white hover:opacity-80">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddPaymentSubmit} className="p-5 space-y-4">
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900 text-xs space-y-1">
                <p className="font-bold text-slate-900 dark:text-white">Facture #{paymentInvoice.invoiceNumber}</p>
                <p className="text-slate-500">Client : {paymentInvoice.customerName}</p>
                <p className="text-rose-600 font-bold">Reste à Payer Actuel : {paymentInvoice.remainingAmount.toLocaleString()} CFA</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Montant du Versement (CFA)
                </label>
                <input
                  type="number"
                  max={paymentInvoice.remainingAmount}
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm font-bold bg-slate-50 dark:bg-slate-900 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Mode de Paiement
                </label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 rounded-xl outline-none text-slate-900 dark:text-white"
                >
                  <option value="cash">Espèces</option>
                  <option value="mobile_money">Wave / Orange Money</option>
                  <option value="check">Chèque</option>
                  <option value="transfer">Virement Bancaire</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Observations / Note de reçu
                </label>
                <input
                  type="text"
                  value={paymentNotes}
                  onChange={e => setPaymentNotes(e.target.value)}
                  placeholder="Ex: Acompte n°2..."
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 rounded-xl outline-none text-slate-900 dark:text-white"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentInvoice(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-md transition-colors"
                >
                  Valider le Paiement
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
