import React, { useState } from 'react';
import {
  UserCog,
  Shield,
  UserCheck,
  Mail,
  Lock,
  Plus,
  Edit,
  Trash2,
  X,
  UserPlus,
  Upload,
  Eye,
  EyeOff,
  Key,
  Store,
  Package,
  CheckSquare,
  Square,
  Search,
  FileText,
  BarChart2,
  DollarSign,
  CheckCircle2,
  AlertCircle,
  ShoppingBag,
  Layers,
  Check,
  LayoutDashboard,
  ShoppingCart,
  AlertOctagon,
  FolderTree,
  FileSpreadsheet,
  CreditCard,
  Warehouse,
  Users as UsersIcon,
  Truck,
  BarChart3,
  Settings,
  ShieldCheck,
  Sliders,
  CheckCheck
} from 'lucide-react';
import { useERP } from '../../context/ERPContext';
import {
  User,
  UserRole,
  Product,
  ERP_MODULES_LIST,
  ROLE_DEFAULT_MODULES,
  ErpModuleId
} from '../../types/erp';

export const UsersView: React.FC = () => {
  const {
    users,
    currentUser,
    setCurrentUser,
    addUser,
    updateUser,
    deleteUser,
    stores,
    addStore,
    products,
    invoices,
    categories
  } = useERP();

  const isUserAdmin = currentUser?.role === 'admin';
  const visibleUsers = isUserAdmin ? users : users.filter(u => u.id === currentUser?.id);

  const [modalOpen, setModalOpen] = useState(false);
  const [modalTab, setModalTab] = useState<'profile' | 'permissions' | 'products' | 'activity'>('profile');
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userToDelete, setUserToDelete] = useState<User | null>(null);
  const [showModalPassword, setShowModalPassword] = useState(false);
  const [visiblePasswords, setVisiblePasswords] = useState<Record<string, boolean>>({});

  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [newStoreInput, setNewStoreInput] = useState('');
  const [isAddingNewStore, setIsAddingNewStore] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    username: '',
    password: '',
    email: '',
    role: 'cashier' as UserRole,
    storeName: stores[0] || 'Boutique Principale',
    avatar: ''
  });

  // Granular ERP permissions (checked modules)
  const [selectedAllowedTabs, setSelectedAllowedTabs] = useState<string[]>([]);

  // Assigned products selection
  const [assignedProductIds, setAssignedProductIds] = useState<string[]>([]);
  const [productSearch, setProductSearch] = useState('');

  // User activity modal view
  const [activityModalUser, setActivityModalUser] = useState<User | null>(null);

  const roleLabels: Record<UserRole, { label: string; badge: string; desc: string }> = {
    admin: {
      label: 'Administrateur (ERP Principal)',
      badge: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-400',
      desc: "Accès total à l'ensemble des 14 modules ERP, gestion des rôles et paramètres."
    },
    manager: {
      label: 'Gestionnaire',
      badge: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-400',
      desc: 'Gestion des stocks, ventes, achats, devis, créances et rapports analytiques.'
    },
    stockkeeper: {
      label: 'Magasinier',
      badge: 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400',
      desc: 'Gestion du stock, catalogue produits, catégories, achats et fournisseurs.'
    },
    cashier: {
      label: 'Caissier (POS)',
      badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400',
      desc: 'Point de Vente (POS), encaissement rapide, factures et suivi des clients.'
    },
    accountant: {
      label: 'Comptable',
      badge: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400',
      desc: 'Factures, paiements, clients endettés, balance fournisseurs et rapports.'
    }
  };

  const moduleIconMap: Record<ErpModuleId, React.ComponentType<{ className?: string }>> = {
    dashboard: LayoutDashboard,
    sales: ShoppingCart,
    debtors: AlertOctagon,
    products: Package,
    categories: FolderTree,
    purchases: ShoppingBag,
    invoices: FileSpreadsheet,
    payments: CreditCard,
    inventory: Warehouse,
    customers: UsersIcon,
    suppliers: Truck,
    reports: BarChart3,
    users: UserCog,
    settings: Settings,
  };

  const moduleThemeMap: Record<ErpModuleId, { iconBg: string; iconColor: string; borderActive: string; bgActive: string; category: string }> = {
    dashboard: {
      iconBg: 'bg-purple-100 dark:bg-purple-950/60',
      iconColor: 'text-purple-600 dark:text-purple-400',
      borderActive: 'border-purple-500 ring-2 ring-purple-500/20',
      bgActive: 'bg-purple-50/60 dark:bg-purple-950/30',
      category: 'Pilotage & ERP Principal'
    },
    sales: {
      iconBg: 'bg-emerald-100 dark:bg-emerald-950/60',
      iconColor: 'text-emerald-600 dark:text-emerald-400',
      borderActive: 'border-emerald-500 ring-2 ring-emerald-500/20',
      bgActive: 'bg-emerald-50/60 dark:bg-emerald-950/30',
      category: 'Vente & Caisse'
    },
    debtors: {
      iconBg: 'bg-rose-100 dark:bg-rose-950/60',
      iconColor: 'text-rose-600 dark:text-rose-400',
      borderActive: 'border-rose-500 ring-2 ring-rose-500/20',
      bgActive: 'bg-rose-50/60 dark:bg-rose-950/30',
      category: 'Vente & Créances'
    },
    products: {
      iconBg: 'bg-blue-100 dark:bg-blue-950/60',
      iconColor: 'text-blue-600 dark:text-blue-400',
      borderActive: 'border-blue-500 ring-2 ring-blue-500/20',
      bgActive: 'bg-blue-50/60 dark:bg-blue-950/30',
      category: 'Catalogue & Articles'
    },
    categories: {
      iconBg: 'bg-teal-100 dark:bg-teal-950/60',
      iconColor: 'text-teal-600 dark:text-teal-400',
      borderActive: 'border-teal-500 ring-2 ring-teal-500/20',
      bgActive: 'bg-teal-50/60 dark:bg-teal-950/30',
      category: 'Catalogue & Rayons'
    },
    purchases: {
      iconBg: 'bg-amber-100 dark:bg-amber-950/60',
      iconColor: 'text-amber-600 dark:text-amber-400',
      borderActive: 'border-amber-500 ring-2 ring-amber-500/20',
      bgActive: 'bg-amber-50/60 dark:bg-amber-950/30',
      category: 'Achats & Commandes'
    },
    invoices: {
      iconBg: 'bg-indigo-100 dark:bg-indigo-950/60',
      iconColor: 'text-indigo-600 dark:text-indigo-400',
      borderActive: 'border-indigo-500 ring-2 ring-indigo-500/20',
      bgActive: 'bg-indigo-50/60 dark:bg-indigo-950/30',
      category: 'Facturation & Devis'
    },
    payments: {
      iconBg: 'bg-cyan-100 dark:bg-cyan-950/60',
      iconColor: 'text-cyan-600 dark:text-cyan-400',
      borderActive: 'border-cyan-500 ring-2 ring-cyan-500/20',
      bgActive: 'bg-cyan-50/60 dark:bg-cyan-950/30',
      category: 'Finance & Règlements'
    },
    inventory: {
      iconBg: 'bg-orange-100 dark:bg-orange-950/60',
      iconColor: 'text-orange-600 dark:text-orange-400',
      borderActive: 'border-orange-500 ring-2 ring-orange-500/20',
      bgActive: 'bg-orange-50/60 dark:bg-orange-950/30',
      category: 'Stock & Dépôts'
    },
    customers: {
      iconBg: 'bg-sky-100 dark:bg-sky-950/60',
      iconColor: 'text-sky-600 dark:text-sky-400',
      borderActive: 'border-sky-500 ring-2 ring-sky-500/20',
      bgActive: 'bg-sky-50/60 dark:bg-sky-950/30',
      category: 'Tiers & Clients'
    },
    suppliers: {
      iconBg: 'bg-lime-100 dark:bg-lime-950/60',
      iconColor: 'text-lime-600 dark:text-lime-400',
      borderActive: 'border-lime-500 ring-2 ring-lime-500/20',
      bgActive: 'bg-lime-50/60 dark:bg-lime-950/30',
      category: 'Tiers & Fournisseurs'
    },
    reports: {
      iconBg: 'bg-violet-100 dark:bg-violet-950/60',
      iconColor: 'text-violet-600 dark:text-violet-400',
      borderActive: 'border-violet-500 ring-2 ring-violet-500/20',
      bgActive: 'bg-violet-50/60 dark:bg-violet-950/30',
      category: 'Pilotage & Analytics'
    },
    users: {
      iconBg: 'bg-fuchsia-100 dark:bg-fuchsia-950/60',
      iconColor: 'text-fuchsia-600 dark:text-fuchsia-400',
      borderActive: 'border-fuchsia-500 ring-2 ring-fuchsia-500/20',
      bgActive: 'bg-fuchsia-50/60 dark:bg-fuchsia-950/30',
      category: 'Administration & Droits'
    },
    settings: {
      iconBg: 'bg-slate-200 dark:bg-slate-700',
      iconColor: 'text-slate-700 dark:text-slate-200',
      borderActive: 'border-slate-500 ring-2 ring-slate-500/20',
      bgActive: 'bg-slate-100 dark:bg-slate-800',
      category: 'Administration & Système'
    }
  };

  const defaultAvatars = [
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80'
  ];

  const handleAvatarFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setFormData(prev => ({ ...prev, avatar: result }));
      }
    };
    reader.readAsDataURL(file);
  };

  const togglePasswordVisibility = (userId: string) => {
    setVisiblePasswords(prev => ({ ...prev, [userId]: !prev[userId] }));
  };

  const handleOpenAdd = () => {
    setEditingUser(null);
    setFormError(null);
    setIsAddingNewStore(false);
    setNewStoreInput('');
    setModalTab('profile');
    setAssignedProductIds([]);
    setProductSearch('');
    setSelectedAllowedTabs([...ROLE_DEFAULT_MODULES.cashier]);
    setFormData({
      name: '',
      username: '',
      password: '',
      email: '',
      role: 'cashier',
      storeName: stores[0] || 'Boutique Principale',
      avatar: defaultAvatars[Math.floor(Math.random() * defaultAvatars.length)]
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (
    u: User,
    initialTab: 'profile' | 'permissions' | 'products' | 'activity' = 'profile'
  ) => {
    setFormError(null);
    if (!isUserAdmin && u.id !== currentUser?.id) {
      setSuccessMessage(null);
      setFormError("Action réservée : Seul l'administrateur est autorisé à modifier les autres comptes utilisateurs.");
      return;
    }
    if (!isUserAdmin && (initialTab === 'permissions' || initialTab === 'products')) {
      setSuccessMessage(null);
      setFormError("Action réservée : Seul l'administrateur peut modifier les rôles, permissions et attributions d'articles.");
      return;
    }
    setEditingUser(u);
    setIsAddingNewStore(false);
    setNewStoreInput('');
    setModalTab(initialTab);
    setAssignedProductIds(u.assignedProductIds || []);
    setProductSearch('');
    const userTabs = u.allowedTabs && u.allowedTabs.length > 0
      ? u.allowedTabs
      : (ROLE_DEFAULT_MODULES[u.role] || ROLE_DEFAULT_MODULES.cashier);
    setSelectedAllowedTabs([...userTabs]);
    setFormData({
      name: u.name,
      username: u.username || u.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''),
      password: u.password || '123456',
      email: u.email || '',
      role: u.role,
      storeName: u.storeName || stores[0] || 'Boutique Principale',
      avatar: u.avatar || defaultAvatars[0]
    });
    setModalOpen(true);
  };

  // Toggle individual ERP permission module
  const toggleAllowedTab = (tabId: string) => {
    setSelectedAllowedTabs(prev =>
      prev.includes(tabId) ? prev.filter(id => id !== tabId) : [...prev, tabId]
    );
  };

  const handleSelectAllTabs = () => {
    setSelectedAllowedTabs(ERP_MODULES_LIST.map(m => m.id));
  };

  const handleDeselectAllTabs = () => {
    setSelectedAllowedTabs([]);
  };

  const handleApplyRolePreset = (role: UserRole) => {
    setFormData(prev => ({ ...prev, role }));
    const defaultTabs = ROLE_DEFAULT_MODULES[role] || ROLE_DEFAULT_MODULES.cashier;
    setSelectedAllowedTabs([...defaultTabs]);
  };

  const toggleProductAssignment = (productId: string) => {
    setAssignedProductIds(prev =>
      prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]
    );
  };

  const handleSelectAllProducts = () => {
    setAssignedProductIds(products.map(p => p.id));
  };

  const handleDeselectAllProducts = () => {
    setAssignedProductIds([]);
  };

  const handleSelectStoreProducts = () => {
    const storeProds = products.filter(
      p => !p.storeName || p.storeName === 'Toutes les boutiques' || p.storeName === formData.storeName
    );
    setAssignedProductIds(storeProds.map(p => p.id));
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setFormError(null);

    const cleanName = formData.name.trim();
    if (!cleanName) {
      setFormError("Veuillez renseigner le nom complet de l'utilisateur.");
      setModalTab('profile');
      return;
    }

    const cleanUsername = (formData.username.trim() || cleanName.toLowerCase().replace(/[^a-zA-Z0-9]/g, '')).toLowerCase();
    if (!cleanUsername) {
      setFormError("Veuillez renseigner un identifiant (Nom d'utilisateur).");
      setModalTab('profile');
      return;
    }

    // Check duplicate username if adding new user or changing username
    const usernameConflict = users.find(
      u => u.username.toLowerCase() === cleanUsername && u.id !== editingUser?.id
    );
    if (usernameConflict) {
      setFormError(`L'identifiant "${cleanUsername}" est déjà utilisé par ${usernameConflict.name}. Choisissez un autre username.`);
      setModalTab('profile');
      return;
    }

    const cleanPassword = formData.password.trim() || '123456';
    const cleanEmail = formData.email.trim() || `${cleanUsername}@alanwary.com`;

    const targetStore = isAddingNewStore && newStoreInput.trim() ? newStoreInput.trim() : formData.storeName;
    if (targetStore) {
      addStore(targetStore);
    }

    const finalAllowedTabs = selectedAllowedTabs.length > 0
      ? selectedAllowedTabs
      : (ROLE_DEFAULT_MODULES[formData.role] || ['sales']);

    setIsSubmitting(true);

    try {
      if (editingUser) {
        if (!isUserAdmin && editingUser.id !== currentUser?.id) {
          setFormError("Action réservée : Seul l'administrateur peut modifier d'autres comptes utilisateurs.");
          setIsSubmitting(false);
          return;
        }

        updateUser(editingUser.id, {
          name: cleanName,
          username: cleanUsername,
          password: cleanPassword,
          email: cleanEmail,
          role: isUserAdmin ? formData.role : editingUser.role,
          storeName: isUserAdmin ? targetStore : editingUser.storeName,
          assignedProductIds: isUserAdmin ? assignedProductIds : editingUser.assignedProductIds,
          allowedTabs: isUserAdmin ? finalAllowedTabs : editingUser.allowedTabs,
          avatar: formData.avatar || editingUser.avatar
        });
        setSuccessMessage(`Les modifications de l'utilisateur "${cleanName}" ont été enregistrées avec succès !`);
      } else {
        addUser({
          name: cleanName,
          username: cleanUsername,
          password: cleanPassword,
          email: cleanEmail,
          role: formData.role,
          storeName: targetStore,
          assignedProductIds: assignedProductIds,
          allowedTabs: finalAllowedTabs,
          avatar: formData.avatar || defaultAvatars[0]
        });
        setSuccessMessage(`L'utilisateur "${cleanName}" (@${cleanUsername}) a été enregistré avec succès avec le mot de passe "${cleanPassword}".`);
      }

      setModalOpen(false);
      setIsSubmitting(false);
    } catch (err: any) {
      console.error('Error saving user:', err);
      setFormError(err?.message || "Erreur lors de l'enregistrement de l'utilisateur.");
      setIsSubmitting(false);
    }
  };

  // Filter products inside modal
  const modalFilteredProducts = products.filter(p => {
    const term = productSearch.toLowerCase();
    return (
      p.name.toLowerCase().includes(term) ||
      p.code.toLowerCase().includes(term) ||
      p.barcode.includes(term) ||
      p.brand.toLowerCase().includes(term)
    );
  });

  return (
    <div className="space-y-6 max-w-6xl">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-2xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-600 dark:bg-purple-950 dark:text-purple-400 flex items-center justify-center font-bold">
            <UserCog className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Gestion des Utilisateurs, Rôles & Accès aux Modules ERP
            </h2>
            <p className="text-xs text-slate-500">
              Attribuez les rôles et cochez précisément les modules ERP autorisés pour chaque compte (POS, Factures, Stocks, Créances...).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 rounded-xl text-xs font-semibold">
            <Shield className="w-4 h-4 text-indigo-500" />
            <span>Session: <strong>{currentUser?.name || 'Administrateur'}</strong></span>
          </div>

          {isUserAdmin && (
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Nouveau Utilisateur</span>
            </button>
          )}
        </div>
      </div>

      {/* Success Notification Banner */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl text-xs text-emerald-800 dark:text-emerald-300 font-bold flex items-center justify-between shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
          <button
            onClick={() => setSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 dark:text-emerald-400 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {visibleUsers.map(u => {
          const isSelected = currentUser.id === u.id;
          const roleInfo = roleLabels[u.role] || roleLabels.cashier;

          const userAllowedTabs = u.allowedTabs && u.allowedTabs.length > 0
            ? u.allowedTabs
            : (ROLE_DEFAULT_MODULES[u.role] || ROLE_DEFAULT_MODULES.cashier);

          // User invoices and sales metrics
          const userInvoices = invoices.filter(
            inv => inv.createdBy === u.name || inv.userId === u.id
          );
          const totalCA = userInvoices.reduce((acc, inv) => acc + inv.totalAmount, 0);
          const assignedCount = u.assignedProductIds ? u.assignedProductIds.length : 0;

          return (
            <div
              key={u.id}
              className={`p-5 rounded-2xl bg-white dark:bg-slate-800 border transition-all space-y-4 ${
                isSelected
                  ? 'border-indigo-500 ring-2 ring-indigo-500/20 shadow-md'
                  : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={u.avatar}
                    alt={u.name}
                    className="w-12 h-12 rounded-xl object-cover ring-2 ring-indigo-500/20 shrink-0"
                  />
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{u.name}</span>
                      {isSelected && (
                        <span className="px-2 py-0.5 text-[10px] font-bold bg-emerald-500 text-white rounded-full">
                          Session active
                        </span>
                      )}
                    </h3>
                    <span className={`inline-block mt-1 px-2.5 py-0.5 rounded-lg text-[10px] font-bold ${roleInfo.badge}`}>
                      {roleInfo.label}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {isUserAdmin ? (
                    <>
                      <button
                        onClick={() => handleOpenEdit(u, 'profile')}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                        title="Modifier l'utilisateur"
                      >
                        <Edit className="w-4 h-4" />
                      </button>

                      {!isSelected && (
                        <button
                          onClick={() => setUserToDelete(u)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg transition-colors cursor-pointer"
                          title="Supprimer l'utilisateur"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </>
                  ) : u.id === currentUser.id ? (
                    <button
                      onClick={() => handleOpenEdit(u, 'profile')}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg transition-colors cursor-pointer"
                      title="Modifier mon profil"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  ) : (
                    <span className="px-2 py-0.5 text-[10px] font-medium text-slate-400 bg-slate-100 dark:bg-slate-750 rounded inline-flex items-center gap-1">
                      <Lock className="w-3 h-3 text-slate-400" />
                      Lecture seule
                    </span>
                  )}

                  {!isSelected && (
                    <button
                      onClick={() => setCurrentUser(u)}
                      className="ml-1 px-2.5 py-1.5 bg-slate-100 hover:bg-indigo-600 text-slate-700 hover:text-white dark:bg-slate-700 dark:hover:bg-indigo-600 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                      title="Basculer vers cette session"
                    >
                      <UserCheck className="w-3.5 h-3.5" />
                      <span>Basculer</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Email & Account info */}
              <div className="flex flex-col gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 truncate pr-2">
                    <Mail className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                    <span className="truncate">{u.email}</span>
                  </div>
                  <div className="flex items-center gap-1.5 bg-purple-50 dark:bg-purple-950/50 px-2.5 py-0.5 rounded-lg border border-purple-200 dark:border-purple-900/50 font-semibold text-purple-700 dark:text-purple-300">
                    <Store className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400 shrink-0" />
                    <span>{u.storeName || 'Boutique Principale'}</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-[11px] bg-slate-50 dark:bg-slate-900/60 px-2.5 py-1.5 rounded-lg border border-slate-100 dark:border-slate-700 font-mono">
                  <span className="text-slate-600 dark:text-slate-300">
                    User: <strong className="text-indigo-600 dark:text-indigo-400">{u.username || u.name.toLowerCase().replace(/\s+/g, '')}</strong>
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-500">
                      Pass: <strong className="text-slate-700 dark:text-slate-200">
                        {visiblePasswords[u.id] ? (u.password || '123456') : '••••••'}
                      </strong>
                    </span>
                    <button
                      type="button"
                      onClick={() => togglePasswordVisibility(u.id)}
                      className="p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors"
                      title={visiblePasswords[u.id] ? "Masquer" : "Afficher"}
                    >
                      {visiblePasswords[u.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              {/* Permitted Modules Summary */}
              <div className="p-3 bg-slate-50/70 dark:bg-slate-900/50 rounded-xl border border-slate-200/70 dark:border-slate-700/60 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="text-[11px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>Modules ERP Autorisés :</span>
                  </p>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    userAllowedTabs.length === ERP_MODULES_LIST.length
                      ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                  }`}>
                    {userAllowedTabs.length} / {ERP_MODULES_LIST.length} modules
                  </span>
                </div>

                <div className="flex flex-wrap gap-1">
                  {ERP_MODULES_LIST.filter(m => userAllowedTabs.includes(m.id)).map(mod => {
                    const ModIcon = moduleIconMap[mod.id];
                    return (
                      <span
                        key={mod.id}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200"
                      >
                        <ModIcon className="w-2.5 h-2.5 text-indigo-500" />
                        <span>{mod.shortName}</span>
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Assigned Products & Sales Summary Bar */}
              <div className="grid grid-cols-2 gap-2 pt-1 border-t border-slate-100 dark:border-slate-700">
                <div className="p-2 bg-blue-50/60 dark:bg-blue-950/30 rounded-xl border border-blue-100 dark:border-blue-900/40">
                  <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase tracking-wider flex items-center gap-1">
                    <Package className="w-3 h-3" />
                    <span>Produits Permis</span>
                  </p>
                  <p className="text-xs font-extrabold text-blue-900 dark:text-blue-200 mt-0.5">
                    {u.role === 'admin' ? (
                      <span className="text-emerald-600 dark:text-emerald-400">Accès Total ({products.length})</span>
                    ) : assignedCount > 0 ? (
                      <span>{assignedCount} produit(s) dédié(s)</span>
                    ) : (
                      <span className="text-slate-500">Tous les produits</span>
                    )}
                  </p>
                </div>

                <div className="p-2 bg-emerald-50/60 dark:bg-emerald-950/30 rounded-xl border border-emerald-100 dark:border-emerald-900/40">
                  <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                    <BarChart2 className="w-3 h-3" />
                    <span>Ventes / CA Réalisé</span>
                  </p>
                  <p className="text-xs font-extrabold text-emerald-900 dark:text-emerald-200 mt-0.5">
                    {totalCA.toLocaleString()} CFA ({userInvoices.length} fact.)
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-3 gap-2 pt-2">
                {isUserAdmin ? (
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(u, 'permissions')}
                    className="py-2 px-2 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 cursor-pointer border border-indigo-200/60 dark:border-indigo-800/60"
                    title="Modifier les rôles et cocher les modules autorisés"
                  >
                    <Sliders className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                    <span className="truncate">Rôles ({userAllowedTabs.length})</span>
                  </button>
                ) : (
                  <div
                    className="py-2 px-2 bg-slate-50 dark:bg-slate-800/60 text-slate-400 rounded-xl text-[11px] font-medium flex items-center justify-center gap-1 border border-slate-200/60 dark:border-slate-700/60"
                    title="Seul l'administrateur peut modifier les rôles"
                  >
                    <Sliders className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{userAllowedTabs.length} mod.</span>
                  </div>
                )}

                {isUserAdmin ? (
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(u, 'products')}
                    className="py-2 px-2 bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/50 dark:hover:bg-blue-900/60 text-blue-700 dark:text-blue-300 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 cursor-pointer border border-blue-200/60 dark:border-blue-800/60"
                    title="Attribuer des articles"
                  >
                    <Package className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span className="truncate">Articles ({assignedCount})</span>
                  </button>
                ) : (
                  <div
                    className="py-2 px-2 bg-slate-50 dark:bg-slate-800/60 text-slate-400 rounded-xl text-[11px] font-medium flex items-center justify-center gap-1 border border-slate-200/60 dark:border-slate-700/60"
                    title="Articles attribués"
                  >
                    <Package className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{assignedCount} art.</span>
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setActivityModalUser(u)}
                  className="py-2 px-2 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/50 dark:hover:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 rounded-xl text-[11px] font-bold transition-all flex items-center justify-center gap-1 cursor-pointer border border-emerald-200/60 dark:border-emerald-800/60"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                  <span className="truncate">Factures</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit User Modal with Tabs */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-6 space-y-4 max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-indigo-600" />
                <div>
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">
                    {editingUser ? `Utilisateur : ${editingUser.name}` : 'Créer un nouvel utilisateur'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    Définissez le profil, cochez les modules ERP autorisés et attribuez les produits.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Tabs Header */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 bg-slate-100 dark:bg-slate-900 p-1 rounded-xl shrink-0">
              <button
                type="button"
                onClick={() => setModalTab('profile')}
                className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                  modalTab === 'profile'
                    ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <UserCog className="w-4 h-4" />
                <span>1. Profil & Compte</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!isUserAdmin) {
                    alert("Action réservée : Seul l'administrateur peut modifier les rôles et permissions.");
                    return;
                  }
                  setModalTab('permissions');
                }}
                className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  !isUserAdmin ? 'opacity-60 cursor-not-allowed text-slate-400' : 'cursor-pointer'
                } ${
                  modalTab === 'permissions'
                    ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {!isUserAdmin ? <Lock className="w-3.5 h-3.5 text-slate-400" /> : <ShieldCheck className="w-4 h-4" />}
                <span>2. Rôles & Accès ({selectedAllowedTabs.length}/14)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  if (!isUserAdmin) {
                    alert("Action réservée : Seul l'administrateur peut attribuer des articles spécifiques.");
                    return;
                  }
                  setModalTab('products');
                }}
                className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  !isUserAdmin ? 'opacity-60 cursor-not-allowed text-slate-400' : 'cursor-pointer'
                } ${
                  modalTab === 'products'
                    ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {!isUserAdmin ? <Lock className="w-3.5 h-3.5 text-slate-400" /> : <Package className="w-4 h-4" />}
                <span>3. Articles ({assignedProductIds.length})</span>
              </button>

              {editingUser ? (
                <button
                  type="button"
                  onClick={() => setModalTab('activity')}
                  className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                    modalTab === 'activity'
                      ? 'bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <BarChart2 className="w-4 h-4" />
                  <span>4. Factures</span>
                </button>
              ) : (
                <div className="py-2 text-[11px] font-semibold text-slate-400 flex items-center justify-center text-center">
                  (Nouvel utilisateur)
                </div>
              )}
            </div>

            {/* Modal Body with scrollable content */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-4">
              {/* Form Error Banner */}
              {formError && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl text-xs text-rose-700 dark:text-rose-300 font-semibold flex items-center gap-2 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* TAB 1: PROFILE FORM */}
              {modalTab === 'profile' && (
                <form id="user-form" onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Nom complet <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Ex: Moussa Diop"
                      value={formData.name}
                      onChange={e => {
                        const newName = e.target.value;
                        setFormData(prev => {
                          const autoUsername = !editingUser && (!prev.username || prev.username === prev.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, ''))
                            ? newName.toLowerCase().replace(/[^a-zA-Z0-9]/g, '')
                            : prev.username;
                          return { ...prev, name: newName, username: autoUsername };
                        });
                      }}
                      className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 text-slate-900 dark:text-white"
                    />
                  </div>

                  {/* Username & Password */}
                  <div className="p-3.5 bg-indigo-50/50 dark:bg-indigo-950/30 rounded-xl border border-indigo-100 dark:border-indigo-900/50 space-y-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-700 dark:text-indigo-300">
                      <Key className="w-4 h-4 text-indigo-500" />
                      <span>Identifiants de Connexion (Username & Mot de passe)</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                          Nom d'utilisateur (Username) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="Ex: moussa"
                          value={formData.username}
                          onChange={e => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                          className="w-full px-3.5 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 text-slate-900 dark:text-white font-mono"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-700 dark:text-slate-300 mb-1">
                          Mot de passe <span className="text-slate-400 font-normal">(Par défaut : 123456)</span>
                        </label>
                        <div className="relative">
                          <input
                            type={showModalPassword ? 'text' : 'password'}
                            placeholder="Ex: 123456"
                            value={formData.password}
                            onChange={e => setFormData({ ...formData, password: e.target.value })}
                            className="w-full pl-3.5 pr-9 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 text-slate-900 dark:text-white font-mono"
                          />
                          <button
                            type="button"
                            onClick={() => setShowModalPassword(!showModalPassword)}
                            className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                          >
                            {showModalPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Adresse Email
                      </label>
                      <span className="text-[10px] text-slate-400 font-normal">
                        (Optionnel - complété automatiquement si vide)
                      </span>
                    </div>
                    <input
                      type="email"
                      placeholder={formData.username ? `${formData.username}@alanwary.com` : 'Ex: caissier@alanwary.com'}
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 text-slate-900 dark:text-white"
                    />
                  </div>

                  {/* Role Selection & Quick Jump to Permissions */}
                  <div className="p-3.5 bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                        Profil / Rôle Principal <span className="text-rose-500">*</span>
                      </label>
                      {isUserAdmin ? (
                        <button
                          type="button"
                          onClick={() => setModalTab('permissions')}
                          className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 cursor-pointer"
                        >
                          <ShieldCheck className="w-3.5 h-3.5" />
                          <span>Personnaliser les {selectedAllowedTabs.length} modules cochés &rarr;</span>
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-400 flex items-center gap-1">
                          <Lock className="w-3 h-3 text-slate-400" />
                          Modifiable par Admin uniquement
                        </span>
                      )}
                    </div>

                    <select
                      value={formData.role}
                      disabled={!isUserAdmin}
                      onChange={e => {
                        const newRole = e.target.value as UserRole;
                        handleApplyRolePreset(newRole);
                      }}
                      className={`w-full px-3.5 py-2.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-indigo-500 text-slate-900 dark:text-white font-semibold ${
                        !isUserAdmin ? 'opacity-70 bg-slate-100 dark:bg-slate-800 cursor-not-allowed' : ''
                      }`}
                    >
                      <option value="cashier">Caissier (POS, Ventes comptant, Factures)</option>
                      <option value="stockkeeper">Magasinier (Stock, Inventaire, Produits, Achats)</option>
                      <option value="accountant">Comptable (Facturation, Règlements, Créances)</option>
                      <option value="manager">Gestionnaire (Pilotage, Ventes, Achats, Rapports)</option>
                      <option value="admin">Administrateur (ERP Principal - Accès Total)</option>
                    </select>

                    <p className="text-[11px] text-slate-500">
                      Astuce : Vous pouvez basculer sur l'onglet <strong>"2. Rôles & Accès"</strong> pour cocher ou décocher librement chacun des 14 modules du système.
                    </p>
                  </div>

                  {/* Boutique / Store Selection */}
                  <div className="p-3.5 bg-purple-50/50 dark:bg-purple-950/30 rounded-xl border border-purple-100 dark:border-purple-900/50 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="flex items-center gap-1.5 text-xs font-bold text-purple-900 dark:text-purple-300">
                        <Store className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                        <span>Boutique / Point de Vente Assigné</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => setIsAddingNewStore(!isAddingNewStore)}
                        className="text-[11px] text-purple-600 dark:text-purple-400 hover:underline font-semibold cursor-pointer"
                      >
                        {isAddingNewStore ? "Choisir boutique existante" : "+ Créer une nouvelle boutique"}
                      </button>
                    </div>

                    {isAddingNewStore ? (
                      <input
                        type="text"
                        placeholder="Nom de la nouvelle boutique (ex: Boutique Pikine)"
                        value={newStoreInput}
                        onChange={e => setNewStoreInput(e.target.value)}
                        className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-purple-500 text-slate-900 dark:text-white"
                      />
                    ) : (
                      <select
                        value={formData.storeName}
                        onChange={e => setFormData({ ...formData, storeName: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:border-purple-500 text-slate-900 dark:text-white font-semibold"
                      >
                        {stores.map((st, idx) => (
                          <option key={idx} value={st}>
                            🏪 {st}
                          </option>
                        ))}
                      </select>
                    )}
                  </div>

                  {/* Local Photo Selection */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                      Photo de profil (Avatar)
                    </label>

                    <div className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-900/60 rounded-2xl border border-slate-200 dark:border-slate-700">
                      <div className="relative group shrink-0">
                        <img
                          src={formData.avatar || defaultAvatars[0]}
                          alt="Preview"
                          className="w-12 h-12 rounded-xl object-cover ring-2 ring-indigo-500/30 shadow-xs"
                        />
                      </div>

                      <div className="flex-1 space-y-2">
                        <label className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all inline-flex items-center gap-1.5 cursor-pointer shadow-md shadow-indigo-600/20 active:scale-95">
                          <Upload className="w-3.5 h-3.5" />
                          <span>Choisir une photo locale</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleAvatarFileChange}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              )}

              {/* TAB 2: GRANULAR PERMISSIONS & MODULE CHECKBOXES */}
              {modalTab === 'permissions' && (
                <div className="space-y-4 animate-in fade-in">
                  {/* Instructions & Header */}
                  <div className="p-4 bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/80 rounded-2xl space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                        <span>Attribution des Rôles & Modules ERP par Cochage</span>
                      </h4>
                      <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-indigo-600 text-white shadow-xs">
                        {selectedAllowedTabs.length} / {ERP_MODULES_LIST.length} modules autorisés
                      </span>
                    </div>
                    <p className="text-xs text-indigo-800/90 dark:text-indigo-300">
                      Cochez ou décochez les modules ci-dessous pour accorder ou restreindre l'accès de <strong>{formData.name || 'cet utilisateur'}</strong>. Les modules non cochés seront masqués et inaccessibles.
                    </p>
                  </div>

                  {/* Preset Fast Actions */}
                  <div className="space-y-1.5">
                    <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
                      Préconfigurations rapides (cliquez pour appliquer) :
                    </p>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleSelectAllTabs}
                        className="px-2.5 py-1.5 text-xs font-bold bg-indigo-100 hover:bg-indigo-200 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <CheckCheck className="w-3.5 h-3.5" />
                        <span>Tout cocher (ERP Principal - 14/14)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyRolePreset('cashier')}
                        className="px-2.5 py-1.5 text-xs font-bold bg-emerald-100 hover:bg-emerald-200 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>Caissier POS (4 modules)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyRolePreset('stockkeeper')}
                        className="px-2.5 py-1.5 text-xs font-bold bg-amber-100 hover:bg-amber-200 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Warehouse className="w-3.5 h-3.5" />
                        <span>Magasinier Stock (6 modules)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyRolePreset('accountant')}
                        className="px-2.5 py-1.5 text-xs font-bold bg-blue-100 hover:bg-blue-200 text-blue-800 dark:bg-blue-950 dark:text-blue-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Comptable (7 modules)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleApplyRolePreset('manager')}
                        className="px-2.5 py-1.5 text-xs font-bold bg-purple-100 hover:bg-purple-200 text-purple-800 dark:bg-purple-950 dark:text-purple-300 rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                        <span>Gestionnaire (12 modules)</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleDeselectAllTabs}
                        className="px-2.5 py-1.5 text-xs font-bold bg-rose-100 hover:bg-rose-200 text-rose-800 dark:bg-rose-950 dark:text-rose-300 rounded-lg transition-colors cursor-pointer"
                      >
                        Tout décocher
                      </button>
                    </div>
                  </div>

                  {/* 14 Modules Checkboxes Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                    {ERP_MODULES_LIST.map(mod => {
                      const isChecked = selectedAllowedTabs.includes(mod.id);
                      const ModIcon = moduleIconMap[mod.id];
                      const theme = moduleThemeMap[mod.id] || {
                        iconBg: 'bg-slate-100 dark:bg-slate-800',
                        iconColor: 'text-slate-700 dark:text-slate-300',
                        borderActive: 'border-indigo-500 ring-2 ring-indigo-500/20',
                        bgActive: 'bg-indigo-50/50 dark:bg-indigo-950/20',
                        category: 'Module'
                      };

                      return (
                        <div
                          key={mod.id}
                          onClick={() => toggleAllowedTab(mod.id)}
                          className={`p-3 rounded-2xl border transition-all cursor-pointer select-none flex items-start justify-between gap-3 ${
                            isChecked
                              ? `${theme.borderActive} ${theme.bgActive} shadow-xs`
                              : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/60 hover:border-slate-300 dark:hover:border-slate-600'
                          }`}
                        >
                          <div className="flex items-start gap-3 min-w-0">
                            {/* Checkbox Visual */}
                            <div className="mt-0.5 shrink-0">
                              {isChecked ? (
                                <div className="w-5 h-5 rounded-lg bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                                  <Check className="w-3.5 h-3.5 stroke-[3]" />
                                </div>
                              ) : (
                                <div className="w-5 h-5 rounded-lg border-2 border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800" />
                              )}
                            </div>

                            {/* Icon & Details */}
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <div className={`w-6 h-6 rounded-lg ${theme.iconBg} ${theme.iconColor} flex items-center justify-center shrink-0`}>
                                  <ModIcon className="w-3.5 h-3.5" />
                                </div>
                                <h5 className={`text-xs font-bold truncate ${
                                  isChecked ? 'text-slate-900 dark:text-white' : 'text-slate-700 dark:text-slate-300'
                                }`}>
                                  {mod.name}
                                </h5>
                              </div>

                              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                                {mod.description}
                              </p>

                              <span className="inline-block mt-1.5 text-[9px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                                {theme.category}
                              </span>
                            </div>
                          </div>

                          {/* Status Badge */}
                          <div className="shrink-0">
                            <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              isChecked
                                ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                                : 'bg-slate-100 text-slate-400 dark:bg-slate-800 dark:text-slate-500'
                            }`}>
                              {isChecked ? 'ACTIF' : 'MASQUÉ'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 3: ASSIGNED PRODUCTS SELECTION */}
              {modalTab === 'products' && (
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl text-xs text-blue-900 dark:text-blue-300 space-y-1">
                    <p className="font-bold flex items-center gap-1.5">
                      <Package className="w-4 h-4 text-blue-600" />
                      <span>Sélection des Produits Autorisés pour {formData.name || 'cet utilisateur'}</span>
                    </p>
                    <p className="text-[11px] text-blue-700 dark:text-blue-400">
                      L'utilisateur verra <strong>UNIQUEMENT</strong> les produits cochés ci-dessous lors de ses encaissements, catalogues et inventaires. Vous pouvez cocher ou décocher des produits individuellement.
                    </p>
                  </div>

                  {/* Actions & Search */}
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-1">
                    <div className="relative w-full sm:w-64">
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        placeholder="Filtrer les produits par nom..."
                        value={productSearch}
                        onChange={e => setProductSearch(e.target.value)}
                        className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none"
                      />
                    </div>

                    <div className="flex items-center gap-1.5 w-full sm:w-auto">
                      <button
                        type="button"
                        onClick={handleSelectAllProducts}
                        className="px-2.5 py-1.5 text-[11px] font-bold bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 rounded-lg cursor-pointer"
                      >
                        Tout cocher
                      </button>
                      <button
                        type="button"
                        onClick={handleDeselectAllProducts}
                        className="px-2.5 py-1.5 text-[11px] font-bold bg-slate-100 dark:bg-slate-700 text-rose-600 dark:text-rose-400 hover:bg-slate-200 rounded-lg cursor-pointer"
                      >
                        Tout décocher
                      </button>
                      <button
                        type="button"
                        onClick={handleSelectStoreProducts}
                        className="px-2.5 py-1.5 text-[11px] font-bold bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 hover:bg-purple-100 rounded-lg cursor-pointer"
                      >
                        Boutique
                      </button>
                    </div>
                  </div>

                  <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 flex items-center justify-between px-1">
                    <span>Produits en catalogue: {products.length}</span>
                    <span className="text-indigo-600 dark:text-indigo-400 font-bold">
                      {assignedProductIds.length} produit(s) coché(s)
                    </span>
                  </div>

                  {/* Products Check List */}
                  <div className="border border-slate-200 dark:border-slate-700 rounded-xl divide-y divide-slate-100 dark:divide-slate-700/60 max-h-80 overflow-y-auto bg-white dark:bg-slate-900">
                    {modalFilteredProducts.length === 0 ? (
                      <div className="p-6 text-center text-xs text-slate-400">
                        Aucun produit ne correspond à la recherche.
                      </div>
                    ) : (
                      modalFilteredProducts.map(p => {
                        const isChecked = assignedProductIds.includes(p.id);
                        return (
                          <div
                            key={p.id}
                            onClick={() => toggleProductAssignment(p.id)}
                            className={`p-3 flex items-center justify-between gap-3 cursor-pointer transition-colors ${
                              isChecked
                                ? 'bg-indigo-50/70 dark:bg-indigo-950/40 hover:bg-indigo-50'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                            }`}
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="shrink-0">
                                {isChecked ? (
                                  <div className="w-5 h-5 rounded-md bg-indigo-600 text-white flex items-center justify-center">
                                    <Check className="w-3.5 h-3.5" />
                                  </div>
                                ) : (
                                  <div className="w-5 h-5 rounded-md border-2 border-slate-300 dark:border-slate-600" />
                                )}
                              </div>

                              <div className="min-w-0">
                                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                                  {p.name}
                                </p>
                                <p className="text-[10px] text-slate-400 font-mono">
                                  Ref: {p.code} | BC: {p.barcode} | Stock: <span className="font-bold text-slate-700 dark:text-slate-200">{p.currentStock} {p.unit}</span>
                                </p>
                              </div>
                            </div>

                            <div className="text-right shrink-0">
                              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                                {p.retailPrice.toLocaleString()} CFA
                              </p>
                              <span className="text-[10px] text-purple-600 dark:text-purple-400 font-medium">
                                {p.storeName || 'Toutes boutiques'}
                              </span>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: USER ACTIVITY & SALES INVOICES */}
              {modalTab === 'activity' && editingUser && (
                <div className="space-y-4">
                  {(() => {
                    const uInvs = invoices.filter(
                      inv => inv.createdBy === editingUser.name || inv.userId === editingUser.id
                    );
                    const totalSales = uInvs.reduce((a, b) => a + b.totalAmount, 0);
                    const totalPaid = uInvs.reduce((a, b) => a + b.paidAmount, 0);
                    const totalRemaining = uInvs.reduce((a, b) => a + b.remainingAmount, 0);

                    return (
                      <>
                        {/* Metrics Grid */}
                        <div className="grid grid-cols-3 gap-3">
                          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl">
                            <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase">
                              Total CA Réalisé
                            </p>
                            <p className="text-sm font-extrabold text-emerald-900 dark:text-emerald-200">
                              {totalSales.toLocaleString()} CFA
                            </p>
                          </div>

                          <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl">
                            <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase">
                              Encaissé / Perçu
                            </p>
                            <p className="text-sm font-extrabold text-blue-900 dark:text-blue-200">
                              {totalPaid.toLocaleString()} CFA
                            </p>
                          </div>

                          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl">
                            <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase">
                              Reste À Recouvrer
                            </p>
                            <p className="text-sm font-extrabold text-rose-900 dark:text-rose-200">
                              {totalRemaining.toLocaleString()} CFA
                            </p>
                          </div>
                        </div>

                        {/* Invoice Table */}
                        <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
                          <div className="p-2.5 bg-slate-50 dark:bg-slate-900 font-bold text-xs text-slate-700 dark:text-slate-300 flex items-center justify-between border-b border-slate-200 dark:border-slate-700">
                            <span>Factures Émises ({uInvs.length})</span>
                          </div>

                          <div className="divide-y divide-slate-100 dark:divide-slate-700/60 max-h-60 overflow-y-auto">
                            {uInvs.length === 0 ? (
                              <p className="p-4 text-center text-xs text-slate-400">
                                Aucune facture n'a encore été créée par cet utilisateur.
                              </p>
                            ) : (
                              uInvs.map(inv => (
                                <div key={inv.id} className="p-2.5 flex items-center justify-between gap-2 text-xs">
                                  <div>
                                    <p className="font-bold text-slate-900 dark:text-white font-mono">
                                      {inv.invoiceNumber}
                                    </p>
                                    <p className="text-[10px] text-slate-400">
                                      Client: {inv.customerName} | {inv.date}
                                    </p>
                                  </div>

                                  <div className="text-right">
                                    <p className="font-bold text-slate-900 dark:text-white">
                                      {inv.totalAmount.toLocaleString()} CFA
                                    </p>
                                    <span
                                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded-md ${
                                        inv.status === 'paid'
                                          ? 'bg-emerald-100 text-emerald-700'
                                          : inv.status === 'partial'
                                          ? 'bg-amber-100 text-amber-700'
                                          : 'bg-rose-100 text-rose-700'
                                      }`}
                                    >
                                      {inv.status.toUpperCase()}
                                    </span>
                                  </div>
                                </div>
                              ))
                            )}
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-700 shrink-0">
              <div className="text-xs text-slate-500">
                <span className="font-bold text-indigo-600 dark:text-indigo-400">{selectedAllowedTabs.length}</span> / {ERP_MODULES_LIST.length} modules autorisés
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  Annuler
                </button>
                <button
                  id="save-user-btn"
                  type="button"
                  disabled={isSubmitting}
                  onClick={() => handleSubmit()}
                  className="px-5 py-2 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-md shadow-indigo-600/20 transition-all flex items-center gap-2 cursor-pointer active:scale-95"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Enregistrement...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>{editingUser ? 'Enregistrer les modifications' : "Enregistrer l'utilisateur"}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-5 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <AlertCircle className="w-6 h-6" />
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Supprimer l'utilisateur ?
              </h3>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Êtes-vous certain de vouloir supprimer <strong>{userToDelete.name}</strong> ? Cette action est irréversible.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setUserToDelete(null)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  if (isUserAdmin) {
                    deleteUser(userToDelete.id);
                  }
                  setUserToDelete(null);
                }}
                className="px-3 py-1.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-md cursor-pointer"
              >
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Activity Modal */}
      {activityModalUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-6 space-y-4 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700 pb-3">
              <div className="flex items-center gap-3">
                <img
                  src={activityModalUser.avatar}
                  alt=""
                  className="w-10 h-10 rounded-xl object-cover ring-2 ring-indigo-500/20"
                />
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Activité & Factures : {activityModalUser.name}
                  </h3>
                  <p className="text-xs text-slate-400">
                    Boutique : {activityModalUser.storeName || 'Boutique Principale'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setActivityModalUser(null)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4">
              {(() => {
                const uInvs = invoices.filter(
                  inv => inv.createdBy === activityModalUser.name || inv.userId === activityModalUser.id
                );
                const totalSales = uInvs.reduce((a, b) => a + b.totalAmount, 0);
                const totalPaid = uInvs.reduce((a, b) => a + b.paidAmount, 0);
                const totalRemaining = uInvs.reduce((a, b) => a + b.remainingAmount, 0);

                return (
                  <>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl">
                        <p className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase">
                          Total CA Réalisé
                        </p>
                        <p className="text-sm font-extrabold text-emerald-900 dark:text-emerald-200">
                          {totalSales.toLocaleString()} CFA
                        </p>
                      </div>

                      <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 rounded-xl">
                        <p className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase">
                          Total Encaissé
                        </p>
                        <p className="text-sm font-extrabold text-blue-900 dark:text-blue-200">
                          {totalPaid.toLocaleString()} CFA
                        </p>
                      </div>

                      <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-xl">
                        <p className="text-[10px] font-bold text-rose-600 dark:text-rose-400 uppercase">
                          Solde Restant
                        </p>
                        <p className="text-sm font-extrabold text-rose-900 dark:text-rose-200">
                          {totalRemaining.toLocaleString()} CFA
                        </p>
                      </div>
                    </div>

                    <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
                      <div className="p-2.5 bg-slate-50 dark:bg-slate-900 font-bold text-xs text-slate-700 dark:text-slate-300 flex items-center justify-between border-b border-slate-200 dark:border-slate-700">
                        <span>Historique des Factures ({uInvs.length})</span>
                      </div>

                      <div className="divide-y divide-slate-100 dark:divide-slate-700/60 max-h-72 overflow-y-auto">
                        {uInvs.length === 0 ? (
                          <p className="p-6 text-center text-xs text-slate-400">
                            Aucune facture générée pour cet utilisateur.
                          </p>
                        ) : (
                          uInvs.map(inv => (
                            <div key={inv.id} className="p-3 flex items-center justify-between gap-3 text-xs">
                              <div>
                                <p className="font-bold text-slate-900 dark:text-white font-mono">
                                  {inv.invoiceNumber}
                                </p>
                                <p className="text-[10px] text-slate-400">
                                  Client: {inv.customerName} | {inv.date}
                                </p>
                              </div>

                              <div className="text-right">
                                <p className="font-bold text-slate-900 dark:text-white">
                                  {inv.totalAmount.toLocaleString()} CFA
                                </p>
                                <span
                                  className={`text-[9px] font-bold px-2 py-0.5 rounded-md ${
                                    inv.status === 'paid'
                                      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-400'
                                      : inv.status === 'partial'
                                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400'
                                      : 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400'
                                  }`}
                                >
                                  {inv.status.toUpperCase()}
                                </span>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
