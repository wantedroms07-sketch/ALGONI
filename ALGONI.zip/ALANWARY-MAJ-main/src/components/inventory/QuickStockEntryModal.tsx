import React, { useState, useId } from 'react';
import { useERP } from '../../context/ERPContext';
import { Product } from '../../types/erp';
import { Package, Plus, ArrowUpRight, Check, X, ShieldCheck, Database, Boxes } from 'lucide-react';

interface QuickStockEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultProductId?: string;
}

export const QuickStockEntryModal: React.FC<QuickStockEntryModalProps> = ({
  isOpen,
  onClose,
  defaultProductId,
}) => {
  const { products, addStockEntry, companySettings } = useERP();
  const selectId = useId();
  const qtyId = useId();
  const reasonId = useId();

  const [selectedProductId, setSelectedProductId] = useState<string>(
    defaultProductId || (products.length > 0 ? products[0].id : '')
  );
  const [entryMode, setEntryMode] = useState<'cartons' | 'pieces'>('cartons');
  const [quantity, setQuantity] = useState<number>(1);
  const [reason, setReason] = useState<string>('Arrivage fournisseur / Réception cartons');
  const [isSuccess, setIsSuccess] = useState(false);

  // Sync if defaultProductId changes
  React.useEffect(() => {
    if (defaultProductId) {
      setSelectedProductId(defaultProductId);
    } else if (!selectedProductId && products.length > 0) {
      setSelectedProductId(products[0].id);
    }
  }, [defaultProductId, products]);

  if (!isOpen) return null;

  const currentProduct = products.find(p => p.id === selectedProductId) || products[0];
  if (!currentProduct) return null;

  const piecesPerBox = currentProduct.piecesPerBox && currentProduct.piecesPerBox > 0
    ? currentProduct.piecesPerBox
    : (currentProduct.unit.toLowerCase() === 'carton' ? 1 : 10);

  const isBoxProduct = piecesPerBox > 1;

  // Real-time proportional calculation
  const currentTotalPieces = currentProduct.currentStock;
  const currentFullCartons = Math.floor(currentTotalPieces / piecesPerBox);
  const currentRemPieces = currentTotalPieces % piecesPerBox;

  const addedPieces = entryMode === 'cartons' ? Math.max(0, quantity) * piecesPerBox : Math.max(0, quantity);
  const projectedTotalPieces = currentTotalPieces + addedPieces;
  const projectedFullCartons = Math.floor(projectedTotalPieces / piecesPerBox);
  const projectedRemPieces = projectedTotalPieces % piecesPerBox;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quantity <= 0) return;

    addStockEntry(
      currentProduct.id,
      quantity,
      entryMode,
      reason
    );

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl max-w-lg w-full overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="p-5 border-b border-slate-100 dark:border-slate-700/80 flex items-center justify-between bg-gradient-to-r from-indigo-50/50 to-emerald-50/50 dark:from-slate-800 dark:to-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 bg-indigo-600 text-white rounded-2xl shadow-sm">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Approvisionnement & Entrée Stock
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Augmentation dynamique des cartons & pièces avec sauvegarde Cloud
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-8 text-center space-y-3">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto animate-bounce">
              <Check className="w-7 h-7" />
            </div>
            <h4 className="text-lg font-bold text-slate-900 dark:text-white">Stock Augmenté & Enregistré !</h4>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Les nouveaux cartons et unités sont synchronisés instantanément dans Firebase Firestore.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            {/* Product selection */}
            <div>
              <label htmlFor={selectId} className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Sélectionner le Produit
              </label>
              <select
                id={selectId}
                value={selectedProductId}
                onChange={e => setSelectedProductId(e.target.value)}
                className="w-full px-3.5 py-2.5 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white font-medium"
              >
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.code}) — Stock actuel : {p.currentStock} {p.unit}s
                  </option>
                ))}
              </select>
            </div>

            {/* Current Stock vs Carton Summary Card */}
            <div className="p-3.5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/60 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-indigo-900 dark:text-indigo-200 flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  État actuel en rayon / dépôt :
                </span>
                <span className="px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300 font-bold text-[11px]">
                  Colisage : {piecesPerBox} {currentProduct.unit}/carton
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
                  <span className="text-[10px] text-slate-500 block">Nombre de Cartons actuels :</span>
                  <span className="text-sm font-black text-slate-900 dark:text-white">
                    📦 {currentFullCartons} ctn{currentFullCartons > 1 ? 's' : ''}
                    {currentRemPieces > 0 && <span className="text-xs font-bold text-indigo-600"> + {currentRemPieces} {currentProduct.unit}</span>}
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-800 p-2.5 rounded-xl border border-indigo-100 dark:border-indigo-900/40">
                  <span className="text-[10px] text-slate-500 block">Stock Total actuel en Unités :</span>
                  <span className="text-sm font-black text-indigo-700 dark:text-indigo-400">
                    {currentTotalPieces} {currentProduct.unit}s
                  </span>
                </div>
              </div>
            </div>

            {/* Mode selection: Cartons or Pieces */}
            <div>
              <span className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                Unité d&apos;Ajout
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setEntryMode('cartons')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    entryMode === 'cartons'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750'
                  }`}
                >
                  <Package className="w-4 h-4" />
                  <span>En Cartons (+{piecesPerBox} un./ctn)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setEntryMode('pieces')}
                  className={`py-2 px-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                    entryMode === 'pieces'
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                      : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750'
                  }`}
                >
                  <Boxes className="w-4 h-4" />
                  <span>En {currentProduct.unit}s directes</span>
                </button>
              </div>
            </div>

            {/* Quantity Input */}
            <div>
              <label htmlFor={qtyId} className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Quantité à Ajouter ({entryMode === 'cartons' ? 'Cartons' : `${currentProduct.unit}s`})
              </label>
              <div className="relative flex items-center">
                <input
                  id={qtyId}
                  type="number"
                  min="1"
                  step="1"
                  value={quantity || ''}
                  onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                  placeholder="Ex: 5"
                  required
                  className="w-full px-3.5 py-2.5 text-sm font-black bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
                />
                <div className="absolute right-2 flex items-center gap-1">
                  {[1, 5, 10, 20].map(quickVal => (
                    <button
                      key={quickVal}
                      type="button"
                      onClick={() => setQuantity(quickVal)}
                      className="px-2 py-1 text-[10px] font-bold rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-indigo-100 hover:text-indigo-700 transition-colors"
                    >
                      +{quickVal}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Real-time Result Preview */}
            <div className="p-3.5 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-black text-emerald-800 dark:text-emerald-300 flex items-center gap-1">
                  <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                  Calcul Proportionnel Après Enregistrement :
                </span>
                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400">
                  +{addedPieces} {currentProduct.unit}s au total
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs pt-0.5">
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-emerald-100 dark:border-emerald-900/60">
                  <span className="text-[10px] text-slate-400 block">Nouveau total Cartons :</span>
                  <span className="text-sm font-black text-emerald-700 dark:text-emerald-400">
                    📦 {projectedFullCartons} ctn{projectedFullCartons > 1 ? 's' : ''}
                    {projectedRemPieces > 0 && ` + ${projectedRemPieces} ${currentProduct.unit}`}
                  </span>
                </div>
                <div className="bg-white dark:bg-slate-800 p-2 rounded-xl border border-emerald-100 dark:border-emerald-900/60">
                  <span className="text-[10px] text-slate-400 block">Nouveau total Unités :</span>
                  <span className="text-sm font-black text-slate-900 dark:text-white">
                    {projectedTotalPieces} {currentProduct.unit}s
                  </span>
                </div>
              </div>
            </div>

            {/* Reason */}
            <div>
              <label htmlFor={reasonId} className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Motif / Justificatif de l&apos;entrée
              </label>
              <input
                id={reasonId}
                type="text"
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="Ex: Réception camion arrivage #45"
                className="w-full px-3.5 py-2 text-xs bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-white"
              />
            </div>

            {/* Cloud Persistence Guarantee Indicator */}
            <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-700 text-[10px] text-slate-500 dark:text-slate-400">
              <Database className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
              <span>
                Persistance Cloud : enregistré dynamiquement dans Firestore. Données conservées après redémarrage et sur plusieurs mois/années.
              </span>
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-end gap-2 border-t border-slate-100 dark:border-slate-700">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-xl transition-colors cursor-pointer"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 text-xs font-black bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Enregistrer l&apos;Entrée de Stock</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
