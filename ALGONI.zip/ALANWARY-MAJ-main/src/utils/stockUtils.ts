/**
 * Utilitaires pour exprimer le stock UNIQUEMENT en carton(s)
 * Conformément aux directives de gestion de stock en cartons pour l'ERP.
 */

export function getCartonsNumber(stock: number, piecesPerBox?: number, unit?: string): number {
  const pBox = piecesPerBox && piecesPerBox > 0 ? piecesPerBox : (unit?.toLowerCase() === 'carton' ? 1 : 10);
  if (stock <= 0) return 0;
  return stock / pBox;
}

export function formatStockInCartons(stock: number, piecesPerBox?: number, unit?: string, short: boolean = false): string {
  const pBox = piecesPerBox && piecesPerBox > 0 ? piecesPerBox : (unit?.toLowerCase() === 'carton' ? 1 : 10);
  if (stock <= 0) return short ? '0 ctn' : '0 carton';

  const rawCartons = stock / pBox;
  const rounded = Math.round(rawCartons * 100) / 100;
  const numStr = rounded.toString().replace('.', ',');

  if (short) {
    return `${numStr} ctn${rounded > 1 ? 's' : ''}`;
  }

  return `${numStr} carton${rounded > 1 ? 's' : ''}`;
}

export function formatCartonBadge(stock: number, piecesPerBox?: number, unit?: string): string {
  const pBox = piecesPerBox && piecesPerBox > 0 ? piecesPerBox : (unit?.toLowerCase() === 'carton' ? 1 : 10);
  if (stock <= 0) return 'Rupture (0 ctn)';
  
  const rawCartons = stock / pBox;
  const rounded = Math.round(rawCartons * 100) / 100;
  const numStr = rounded.toString().replace('.', ',');

  return `${numStr} ctn${rounded > 1 ? 's' : ''}`;
}
