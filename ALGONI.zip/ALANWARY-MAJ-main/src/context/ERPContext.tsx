import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { subscribeToDoc, updateDocValue, forceSaveAllToCloud } from '../firebase';
import {
  Product,
  Category,
  Supplier,
  Customer,
  DebtorCustomer,
  Invoice,
  PaymentMethod,
  PurchaseOrder,
  PaymentRecord,
  StockMovement,
  SystemNotification,
  CompanySettings,
  User,
  UserRole,
  Language,
  Theme,
  RiskLevel,
  ERP_MODULES_LIST,
  ROLE_DEFAULT_MODULES,
  ErpModuleId
} from '../types/erp';
import {
  initialCompanySettings,
  initialCategories,
  initialProducts,
  initialSuppliers,
  initialCustomers,
  initialInvoices,
  initialPurchases,
  initialPayments,
  initialStockMovements,
  initialNotifications,
  initialUsers,
  initialStores
} from '../data/mockData';
import { translations } from '../i18n/translations';

interface ERPContextType {
  // State
  activeTab: string;
  setActiveTab: (tab: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  currentUser: User;
  setCurrentUser: (user: User) => void;
  globalSearchOpen: boolean;
  setGlobalSearchOpen: (open: boolean) => void;

  companySettings: CompanySettings;
  updateCompanySettings: (settings: Partial<CompanySettings>) => void;

  categories: Category[];
  addCategory: (cat: Omit<Category, 'id'>) => void;
  updateCategory: (id: string, cat: Partial<Category>) => void;
  deleteCategory: (id: string) => void;

  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;

  suppliers: Supplier[];
  addSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt' | 'balance'>) => void;
  updateSupplier: (id: string, supplier: Partial<Supplier>) => void;
  deleteSupplier: (id: string) => void;

  customers: Customer[];
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt'>) => void;
  updateCustomer: (id: string, customer: Partial<Customer>) => void;
  deleteCustomer: (id: string) => void;

  debtors: DebtorCustomer[];

  invoices: Invoice[];
  createInvoice: (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'>) => Invoice;
  updateInvoice: (id: string, updatedData: Partial<Invoice>, options?: { adjustStock?: boolean }) => void;
  deleteInvoice: (id: string, options?: { restoreStock?: boolean }) => void;
  addPaymentToInvoice: (invoiceId: string, amount: number, paymentMethod?: string, notes?: string) => void;

  purchases: PurchaseOrder[];
  createPurchaseOrder: (purchaseData: Omit<PurchaseOrder, 'id' | 'orderNumber'>) => PurchaseOrder;

  payments: PaymentRecord[];
  addPayment: (paymentData: Omit<PaymentRecord, 'id'>) => PaymentRecord;

  stockMovements: StockMovement[];
  addStockMovement: (mov: Omit<StockMovement, 'id'>) => void;

  notifications: SystemNotification[];
  markNotificationAsRead: (id: string) => void;
  clearAllNotifications: () => void;

  users: User[];
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;

  stores: string[];
  addStore: (name: string) => void;

  canAccessTab: (tabId: string, user?: User) => boolean;

  isAdmin: boolean;
  adjustStock: (productId: string, newStock: number, reason?: string) => void;
  addStockEntry: (productId: string, quantityToAdd: number, mode?: 'cartons' | 'pieces', reason?: string) => void;
  deletePurchaseOrder: (id: string) => void;

  isAuthenticated: boolean;
  login: (username: string, password: string) => { success: boolean; message?: string };
  logout: () => void;
  
  // Backup, Restore & Cloud Sync
  exportDatabaseBackup: () => void;
  importDatabaseBackup: (backupData: any) => Promise<{ success: boolean; message: string; counts?: Record<string, number> }>;
  forceCloudSync: () => Promise<{ success: boolean; message: string; timestamp: string }>;

  // Helpers
  resetDemoData: () => void;
  t: (key: string) => string;
}

const STORAGE_PREFIX = 'odoo_erp_store_v1_';

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const saved = localStorage.getItem(STORAGE_PREFIX + key);
    return saved ? JSON.parse(saved) : defaultValue;
  } catch (e) {
    console.error('Failed to parse storage key:', key, e);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T) {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.error('Failed to save storage key:', key, e);
  }
}

const ERPContext = createContext<ERPContextType | undefined>(undefined);

export const ERPProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => {
    const loaded = loadFromStorage('settings', initialCompanySettings);
    if (!loaded.name || loaded.name.includes('Odoo') || loaded.name.includes('OdooERP') || loaded.name.includes('WAD-ALGONI')) {
      return {
        ...loaded,
        name: 'ALANWARY BUSINESS INTERNATIONAL',
        email: loaded.email && (loaded.email.includes('odoo') || loaded.email.includes('wad-algoni')) ? 'contact@alanwary.com' : (loaded.email || 'contact@alanwary.com')
      };
    }
    return loaded;
  });

  const [language, setLanguageState] = useState<Language>(companySettings.language);
  const [theme, setThemeState] = useState<Theme>(companySettings.theme);
  
  const [users, setUsers] = useState<User[]>(() => {
    const loaded = loadFromStorage('users', initialUsers);
    if (!Array.isArray(loaded) || loaded.length === 0) return initialUsers;
    return loaded.map((u: User) => {
      const matchInit = initialUsers.find(iu => iu.id === u.id || iu.email === u.email);
      const fallbackAllowedTabs = u.allowedTabs && Array.isArray(u.allowedTabs) && u.allowedTabs.length > 0
        ? u.allowedTabs
        : (matchInit?.allowedTabs || ROLE_DEFAULT_MODULES[u.role] || ROLE_DEFAULT_MODULES.cashier);

      if (u.role === 'admin' || u.id === 'usr-1') {
        return {
          ...u,
          name: u.name && !u.name.includes('Amadou') ? u.name : 'Administrateur ALANWARY',
          username: 'alanwary',
          password: '6326',
          email: u.email && (u.email.includes('wad-algoni') || u.email.includes('odoo')) ? 'admin@alanwary.com' : (u.email || 'admin@alanwary.com'),
          storeName: u.storeName || 'Boutique Principale',
          allowedTabs: fallbackAllowedTabs
        };
      }
      return {
        ...u,
        username: u.username || matchInit?.username || u.name.toLowerCase().replace(/\s+/g, ''),
        password: u.password || matchInit?.password || '123456',
        storeName: u.storeName || matchInit?.storeName || 'Boutique Principale',
        assignedProductIds: u.assignedProductIds !== undefined ? u.assignedProductIds : (matchInit?.assignedProductIds || []),
        allowedTabs: fallbackAllowedTabs
      };
    });
  });
  const [currentUser, setCurrentUser] = useState<User>(() =>
    loadFromStorage('currentUser', users[0] || initialUsers[0])
  );
  const isAdmin = currentUser?.role === 'admin';

  useEffect(() => {
    if (currentUser) {
      saveToStorage('currentUser', currentUser);
    }
  }, [currentUser]);

  const notifyUnauthorized = (actionName: string = 'Cette action') => {
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setNotifications(prev => [
      {
        id: 'notif-' + Date.now(),
        type: 'warning' as const,
        title: 'Action Restreinte (Admin Requis)',
        message: `Action refusée (${actionName}) : Seul l'administrateur est autorisé à modifier ou supprimer les enregistrements.`,
        date: nowStr,
        read: false,
        severity: 'danger' as const,
      },
      ...prev
    ]);
  };
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() =>
    loadFromStorage('isAuthenticated', false)
  );

  const [stores, setStores] = useState<string[]>(() =>
    loadFromStorage('stores', initialStores)
  );

  useEffect(() => {
    saveToStorage('stores', stores);
  }, [stores]);

  const addStore = (storeName: string) => {
    const trimmed = storeName.trim();
    if (!trimmed) return;
    if (!stores.includes(trimmed)) {
      setStores(prev => {
        const next = [...prev, trimmed];
        updateDocValue('stores', next);
        return next;
      });
    }
  };

  const [globalSearchOpen, setGlobalSearchOpen] = useState<boolean>(false);

  const [categories, setCategories] = useState<Category[]>(() =>
    loadFromStorage('categories', initialCategories)
  );
  const [products, setProducts] = useState<Product[]>(() =>
    loadFromStorage('products', initialProducts)
  );
  const productsRef = useRef<Product[]>(products);
  useEffect(() => {
    productsRef.current = products;
  }, [products]);
  const [suppliers, setSuppliers] = useState<Supplier[]>(() =>
    loadFromStorage('suppliers', initialSuppliers)
  );
  const [customers, setCustomers] = useState<Customer[]>(() =>
    loadFromStorage('customers', initialCustomers)
  );
  const [invoices, setInvoices] = useState<Invoice[]>(() =>
    loadFromStorage('invoices', initialInvoices)
  );
  const [purchases, setPurchases] = useState<PurchaseOrder[]>(() =>
    loadFromStorage('purchases', initialPurchases)
  );
  const [payments, setPayments] = useState<PaymentRecord[]>(() =>
    loadFromStorage('payments', initialPayments)
  );
  const [stockMovements, setStockMovements] = useState<StockMovement[]>(() =>
    loadFromStorage('stockMovements', initialStockMovements)
  );
  const [notifications, setNotifications] = useState<SystemNotification[]>(() =>
    loadFromStorage('notifications', initialNotifications)
  );

  // Sync effect with localStorage
  useEffect(() => { saveToStorage('settings', companySettings); }, [companySettings]);
  useEffect(() => { saveToStorage('categories', categories); }, [categories]);
  useEffect(() => { saveToStorage('products', products); }, [products]);
  useEffect(() => { saveToStorage('suppliers', suppliers); }, [suppliers]);
  useEffect(() => { saveToStorage('customers', customers); }, [customers]);
  useEffect(() => { saveToStorage('invoices', invoices); }, [invoices]);
  useEffect(() => { saveToStorage('purchases', purchases); }, [purchases]);
  useEffect(() => { saveToStorage('payments', payments); }, [payments]);
  useEffect(() => { saveToStorage('stockMovements', stockMovements); }, [stockMovements]);
  useEffect(() => { saveToStorage('notifications', notifications); }, [notifications]);
  useEffect(() => { saveToStorage('users', users); }, [users]);

  // Real-time synchronization across all devices via Firebase Firestore
  useEffect(() => {
    const unsubSettings = subscribeToDoc<CompanySettings>('settings', (val) => setCompanySettings(val), companySettings);
    const unsubCategories = subscribeToDoc<Category[]>('categories', (val) => setCategories(val), loadFromStorage('categories', initialCategories));
    const unsubProducts = subscribeToDoc<Product[]>('products', (val) => setProducts(val), loadFromStorage('products', initialProducts));
    const unsubSuppliers = subscribeToDoc<Supplier[]>('suppliers', (val) => setSuppliers(val), loadFromStorage('suppliers', initialSuppliers));
    const unsubCustomers = subscribeToDoc<Customer[]>('customers', (val) => setCustomers(val), loadFromStorage('customers', initialCustomers));
    const unsubInvoices = subscribeToDoc<Invoice[]>('invoices', (val) => setInvoices(val), loadFromStorage('invoices', initialInvoices));
    const unsubPurchases = subscribeToDoc<PurchaseOrder[]>('purchases', (val) => setPurchases(val), loadFromStorage('purchases', initialPurchases));
    const unsubPayments = subscribeToDoc<PaymentRecord[]>('payments', (val) => setPayments(val), loadFromStorage('payments', initialPayments));
    const unsubStockMovements = subscribeToDoc<StockMovement[]>('stockMovements', (val) => setStockMovements(val), loadFromStorage('stockMovements', initialStockMovements));
    const unsubNotifications = subscribeToDoc<SystemNotification[]>('notifications', (val) => setNotifications(val), loadFromStorage('notifications', initialNotifications));
    const unsubUsers = subscribeToDoc<User[]>('users', (val) => {
      if (Array.isArray(val) && val.length > 0) {
        setUsers(val);
        setCurrentUser(prev => {
          if (!prev) return val[0];
          const match = val.find(u => u.id === prev.id || u.username === prev.username);
          return match || prev;
        });
      }
    }, loadFromStorage('users', initialUsers));
    const unsubStores = subscribeToDoc<string[]>('stores', (val) => setStores(val), loadFromStorage('stores', initialStores));

    return () => {
      unsubSettings();
      unsubCategories();
      unsubProducts();
      unsubSuppliers();
      unsubCustomers();
      unsubInvoices();
      unsubPurchases();
      unsubPayments();
      unsubStockMovements();
      unsubNotifications();
      unsubUsers();
      unsubStores();
    };
  }, []);

  // Handle RTL vs LTR attribute on <html> element
  useEffect(() => {
    const htmlEl = document.documentElement;
    if (language === 'ar') {
      htmlEl.setAttribute('dir', 'rtl');
      htmlEl.setAttribute('lang', 'ar');
    } else {
      htmlEl.setAttribute('dir', 'ltr');
      htmlEl.setAttribute('lang', language);
    }
  }, [language]);

  // Handle dark mode class on <html> element
  useEffect(() => {
    const htmlEl = document.documentElement;
    if (theme === 'dark') {
      htmlEl.classList.add('dark');
    } else {
      htmlEl.classList.remove('dark');
    }
  }, [theme]);

  // Handle primary color theme attribute on <html> element
  useEffect(() => {
    const htmlEl = document.documentElement;
    const color = companySettings.primaryColor || 'emerald';
    htmlEl.setAttribute('data-color', color);
  }, [companySettings.primaryColor]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    setCompanySettings(prev => {
      const next = { ...prev, language: lang };
      updateDocValue('settings', next);
      return next;
    });
  };

  const setTheme = (t: Theme) => {
    setThemeState(t);
    setCompanySettings(prev => {
      const next = { ...prev, theme: t };
      updateDocValue('settings', next);
      return next;
    });
  };

  const updateCompanySettings = (newSettings: Partial<CompanySettings>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification des paramètres');
      return;
    }
    setCompanySettings(prev => {
      const next = { ...prev, ...newSettings };
      updateDocValue('settings', next);
      return next;
    });
  };

  // Category Actions
  const addCategory = (cat: Omit<Category, 'id'>) => {
    const newCat: Category = { ...cat, id: 'cat-' + Date.now() };
    setCategories(prev => {
      const next = [...prev, newCat];
      updateDocValue('categories', next);
      return next;
    });
  };
  const updateCategory = (id: string, cat: Partial<Category>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification de catégorie');
      return;
    }
    setCategories(prev => {
      const next = prev.map(c => c.id === id ? { ...c, ...cat } : c);
      updateDocValue('categories', next);
      return next;
    });
  };
  const deleteCategory = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de catégorie');
      return;
    }
    setCategories(prev => {
      const next = prev.filter(c => c.id !== id);
      updateDocValue('categories', next);
      return next;
    });
  };

  // Product Actions
  const addProduct = (p: Omit<Product, 'id' | 'createdAt'>) => {
    const newProd: Product = {
      ...p,
      id: 'prod-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setProducts(prev => {
      const next = [newProd, ...prev];
      updateDocValue('products', next);
      return next;
    });

    // Record initial stock entry movement
    if (p.currentStock > 0) {
      addStockMovement({
        date: new Date().toISOString().replace('T', ' ').substring(0, 16),
        productId: newProd.id,
        productCode: newProd.code,
        productName: newProd.name,
        type: 'in',
        quantity: p.currentStock,
        previousStock: 0,
        newStock: p.currentStock,
        reason: 'Initialisation du produit',
        location: p.location,
        performedBy: currentUser.name,
      });
    }
  };
  const updateProduct = (id: string, p: Partial<Product>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification de produit');
      return;
    }
    setProducts(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...p } : item);
      updateDocValue('products', next);
      return next;
    });
  };
  const deleteProduct = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de produit');
      return;
    }
    setProducts(prev => {
      const next = prev.filter(item => item.id !== id);
      updateDocValue('products', next);
      return next;
    });
  };

  // Supplier Actions
  const addSupplier = (s: Omit<Supplier, 'id' | 'createdAt' | 'balance'>) => {
    const newSup: Supplier = {
      ...s,
      id: 'sup-' + Date.now(),
      balance: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setSuppliers(prev => {
      const next = [newSup, ...prev];
      updateDocValue('suppliers', next);
      return next;
    });
  };
  const updateSupplier = (id: string, s: Partial<Supplier>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification de fournisseur');
      return;
    }
    setSuppliers(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...s } : item);
      updateDocValue('suppliers', next);
      return next;
    });
  };
  const deleteSupplier = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de fournisseur');
      return;
    }
    setSuppliers(prev => {
      const next = prev.filter(item => item.id !== id);
      updateDocValue('suppliers', next);
      return next;
    });
  };

  // Customer Actions
  const addCustomer = (c: Omit<Customer, 'id' | 'createdAt'>) => {
    const newCust: Customer = {
      ...c,
      id: 'cust-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomers(prev => {
      const next = [newCust, ...prev];
      updateDocValue('customers', next);
      return next;
    });
  };
  const updateCustomer = (id: string, c: Partial<Customer>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification de client');
      return;
    }
    setCustomers(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...c } : item);
      updateDocValue('customers', next);
      return next;
    });
  };
  const deleteCustomer = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de client');
      return;
    }
    setCustomers(prev => {
      const next = prev.filter(item => item.id !== id);
      updateDocValue('customers', next);
      return next;
    });
  };

  // User Actions
  const addUser = (u: Omit<User, 'id'>) => {
    const defaultTabs = u.allowedTabs && u.allowedTabs.length > 0
      ? u.allowedTabs
      : (ROLE_DEFAULT_MODULES[u.role] || ROLE_DEFAULT_MODULES.cashier);

    const cleanUsername = (u.username?.trim() || u.name.toLowerCase().replace(/[^a-zA-Z0-9]/g, '')).toLowerCase();
    const cleanEmail = u.email?.trim() || `${cleanUsername || 'user'}@alanwary.com`;

    const newUser: User = {
      ...u,
      id: 'usr-' + Date.now(),
      name: u.name.trim(),
      username: cleanUsername,
      password: u.password?.trim() || '123456',
      email: cleanEmail,
      allowedTabs: defaultTabs,
      avatar: u.avatar || `https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80`
    };
    setUsers(prev => {
      const next = [...prev, newUser];
      updateDocValue('users', next);
      return next;
    });

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setNotifications(prev => [
      {
        id: 'notif-' + Date.now(),
        type: 'info' as const,
        title: 'Utilisateur Enregistré',
        message: `L'utilisateur "${newUser.name}" (@${newUser.username}) a été enregistré avec succès.`,
        date: nowStr,
        read: false,
        severity: 'success' as const,
        linkTab: 'users'
      },
      ...prev
    ]);
  };

  const updateUser = (id: string, u: Partial<User>) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized("Modification d'utilisateur");
      return;
    }
    setUsers(prev => {
      const next = prev.map(item => item.id === id ? { ...item, ...u } : item);
      updateDocValue('users', next);
      return next;
    });
    if (currentUser.id === id) {
      setCurrentUser(prev => ({ ...prev, ...u }));
    }

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setNotifications(prev => [
      {
        id: 'notif-' + Date.now(),
        type: 'info' as const,
        title: 'Utilisateur Mis à Jour',
        message: `Les informations de l'utilisateur ont été mises à jour avec succès.`,
        date: nowStr,
        read: false,
        severity: 'info' as const,
        linkTab: 'users'
      },
      ...prev
    ]);
  };

  const canAccessTab = (tabId: string, userToTest?: User): boolean => {
    const target = userToTest || currentUser;
    if (!target) return false;
    // If admin with empty or all allowedTabs, give full access
    if (target.role === 'admin' && (!target.allowedTabs || target.allowedTabs.length === 0)) {
      return true;
    }
    // If explicit allowedTabs are present
    if (target.allowedTabs && Array.isArray(target.allowedTabs) && target.allowedTabs.length > 0) {
      return target.allowedTabs.includes(tabId);
    }
    // Fallback to role presets
    const fallback = ROLE_DEFAULT_MODULES[target.role] || ROLE_DEFAULT_MODULES.cashier;
    return fallback.includes(tabId as ErpModuleId);
  };

  const deleteUser = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized("Suppression d'utilisateur");
      return;
    }
    if (currentUser.id === id) {
      alert("Impossible de supprimer l'utilisateur actuellement connecté.");
      return;
    }
    setUsers(prev => {
      const next = prev.filter(item => item.id !== id);
      updateDocValue('users', next);
      return next;
    });
  };

  // Auth Actions
  const login = (usernameInput: string, passwordInput: string): { success: boolean; message?: string } => {
    const cleanUsername = usernameInput.trim().toLowerCase();
    const cleanPassword = passwordInput.trim();

    const foundUser = users.find(u => {
      const uName = (u.name || '').toLowerCase();
      const uUsername = (u.username || u.name.toLowerCase().replace(/\s+/g, '')).toLowerCase();
      const uEmail = (u.email || '').toLowerCase();

      const isMatchAdmin = (u.id === 'usr-1' || u.role === 'admin') &&
        (cleanUsername === 'alanwary' || cleanUsername === 'algoni' || cleanUsername === 'admin');

      return isMatchAdmin || cleanUsername === uUsername || cleanUsername === uName || cleanUsername === uEmail;
    });

    if (!foundUser) {
      return { success: false, message: "Nom d'utilisateur ou email introuvable. (Ex: alanwary)" };
    }

    const expectedPassword = foundUser.password || (foundUser.role === 'admin' ? '6326' : '123456');

    if (expectedPassword !== cleanPassword) {
      return { success: false, message: "Mot de passe incorrect." };
    }

    setCurrentUser(foundUser);
    setIsAuthenticated(true);
    saveToStorage('isAuthenticated', true);
    return { success: true };
  };

  const logout = () => {
    setIsAuthenticated(false);
    saveToStorage('isAuthenticated', false);
  };

  // Compute Debtors dynamically (CLIENTS ENDETTÉS)
  // Filtering customers whose total remaining unpaid balance > 0, ranking by highest debt
  const computeDebtors = (): DebtorCustomer[] => {
    const todayMs = Date.now();
    const debtorsMap: Record<string, DebtorCustomer> = {};

    customers.forEach(cust => {
      const custInvoices = invoices.filter(
        i => i.customerId === cust.id || (i.customerName && cust.name && i.customerName.trim().toLowerCase() === cust.name.trim().toLowerCase())
      );
      const totalPurchased = custInvoices.reduce((sum, i) => sum + i.totalAmount, 0);
      const totalPaid = custInvoices.reduce((sum, i) => sum + i.paidAmount, 0);
      const remainingBalance = custInvoices.reduce((sum, i) => sum + i.remainingAmount, 0);

      const unpaidInvoices = custInvoices.filter(i => i.remainingAmount > 0);
      const unpaidInvoiceCount = unpaidInvoices.length;

      if (remainingBalance > 0 || unpaidInvoiceCount > 0) {
        let lastInvoiceDate = cust.createdAt;
        let earliestDueDate = '';
        let maxOverdueDays = 0;

        if (custInvoices.length > 0) {
          const sorted = [...custInvoices].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
          lastInvoiceDate = sorted[0].date;
        }

        if (unpaidInvoices.length > 0) {
          const sortedUnpaid = [...unpaidInvoices].sort((a, b) => new Date(a.dueDate || a.date).getTime() - new Date(b.dueDate || b.date).getTime());
          earliestDueDate = sortedUnpaid[0].dueDate || sortedUnpaid[0].date;
          const dueMs = new Date(earliestDueDate).getTime();
          const diffDays = Math.floor((todayMs - dueMs) / (1000 * 60 * 60 * 24));
          maxOverdueDays = Math.max(0, diffDays);
        }

        let riskLevel: RiskLevel = 'green';
        if (maxOverdueDays > 30) {
          riskLevel = 'red';
        } else if (maxOverdueDays >= 15) {
          riskLevel = 'orange';
        }

        debtorsMap[cust.id] = {
          ...cust,
          lastInvoiceDate,
          unpaidInvoiceCount,
          totalPurchased,
          totalPaid,
          remainingBalance,
          overdueDays: maxOverdueDays,
          riskLevel,
        };
      }
    });

    // Also include any debtors from invoices with remainingAmount > 0 not registered in customers list
    invoices.forEach(inv => {
      if (inv.remainingAmount > 0) {
        const found = Object.values(debtorsMap).find(
          d => d.id === inv.customerId || (d.name && inv.customerName && d.name.trim().toLowerCase() === inv.customerName.trim().toLowerCase())
        );
        if (!found) {
          const debtId = inv.customerId || `debtor-${inv.id}`;
          const dueMs = new Date(inv.dueDate || inv.date).getTime();
          const diffDays = Math.floor((todayMs - dueMs) / (1000 * 60 * 60 * 24));
          const overdueDays = Math.max(0, diffDays);

          debtorsMap[debtId] = {
            id: debtId,
            name: inv.customerName,
            phone: inv.customerPhone || 'Non renseigné',
            email: '',
            address: 'Comptoir Vente Directe',
            neighborhood: '',
            city: 'Dakar',
            country: 'Sénégal',
            createdAt: inv.date,
            lastInvoiceDate: inv.date,
            unpaidInvoiceCount: 1,
            totalPurchased: inv.totalAmount,
            totalPaid: inv.paidAmount,
            remainingBalance: inv.remainingAmount,
            overdueDays,
            riskLevel: overdueDays > 30 ? 'red' : overdueDays >= 15 ? 'orange' : 'green',
          };
        }
      }
    });

    return Object.values(debtorsMap).sort((a, b) => b.remainingBalance - a.remainingBalance);
  };

  const debtors = computeDebtors();

  // Create Invoice (Sale)
  const createInvoice = (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'>): Invoice => {
    const invCount = invoices.length + 1;
    const invNum = `FACT-2026-${String(invCount).padStart(4, '0')}`;
    
    const newInvoice: Invoice = {
      ...invoiceData,
      id: 'inv-' + Date.now(),
      invoiceNumber: invNum,
    };

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    
    // Accumulate stock changes, stock movements, and notifications in one clean pass
    let updatedProducts = [...(productsRef.current || products)];
    const generatedMovements: StockMovement[] = [];
    const generatedNotifs: SystemNotification[] = [];

    invoiceData.items.forEach(item => {
      const idx = updatedProducts.findIndex(p => p.id === item.productId);
      if (idx !== -1) {
        const p = updatedProducts[idx];
        const newStock = Math.max(0, p.currentStock - item.quantity);

        if (newStock === 0) {
          generatedNotifs.push({
            id: 'notif-' + Date.now() + Math.random(),
            type: 'out_of_stock' as const,
            title: 'Rupture de Stock',
            message: `Le produit ${p.name} est à présent en rupture de stock !`,
            date: nowStr,
            read: false,
            severity: 'danger' as const,
            linkTab: 'products'
          });
        } else if (newStock <= p.minStock) {
          generatedNotifs.push({
            id: 'notif-' + Date.now() + Math.random(),
            type: 'low_stock' as const,
            title: 'Stock Faible',
            message: `Le produit ${p.name} a atteint son seuil minimum (${newStock}/${p.minStock}).`,
            date: nowStr,
            read: false,
            severity: 'warning' as const,
            linkTab: 'inventory'
          });
        }

        generatedMovements.push({
          id: 'mov-' + Date.now() + Math.random(),
          date: nowStr,
          productId: p.id,
          productCode: p.code,
          productName: p.name,
          type: 'out',
          quantity: item.quantity,
          previousStock: p.currentStock,
          newStock: newStock,
          reference: invNum,
          reason: `Vente Facture ${invNum} (${newInvoice.customerName})`,
          location: p.location,
          performedBy: currentUser.name,
        });

        updatedProducts[idx] = { ...p, currentStock: newStock };
      }
    });

    if (generatedNotifs.length > 0) {
      setNotifications(prev => {
        const next = [...generatedNotifs, ...prev];
        updateDocValue('notifications', next);
        return next;
      });
    }

    if (generatedMovements.length > 0) {
      setStockMovements(prev => {
        const next = [...generatedMovements, ...prev];
        updateDocValue('stockMovements', next);
        return next;
      });
    }

    setProducts(updatedProducts);
    updateDocValue('products', updatedProducts);

    // Record immediate payment log if paidAmount > 0
    if (newInvoice.paidAmount > 0) {
      addPayment({
        reference: `REC-2026-${String(payments.length + 1).padStart(3, '0')}`,
        date: newInvoice.date,
        type: 'sale',
        targetId: newInvoice.id,
        targetNumber: invNum,
        entityId: newInvoice.customerId,
        entityName: newInvoice.customerName,
        amount: newInvoice.paidAmount,
        paymentMethod: newInvoice.paymentMethod,
        notes: `Paiement à la création de la facture ${invNum}`,
        receivedBy: currentUser.name,
      });
    }

    setInvoices(prev => {
      const next = [newInvoice, ...prev];
      updateDocValue('invoices', next);
      return next;
    });
    return newInvoice;
  };

  // Update Invoice
  const updateInvoice = (
    id: string,
    updatedData: Partial<Invoice>,
    options: { adjustStock?: boolean } = { adjustStock: true }
  ) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Modification de facture');
      return;
    }
    const existingInvoice = invoices.find(inv => inv.id === id);
    if (!existingInvoice) return;

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    let updatedProducts = [...products];
    const generatedMovements: StockMovement[] = [];

    // If adjustStock is enabled and items are modified
    if (options.adjustStock !== false && updatedData.items) {
      // 1. Revert previous items stock
      existingInvoice.items.forEach(oldItem => {
        const pIdx = updatedProducts.findIndex(p => p.id === oldItem.productId);
        if (pIdx !== -1) {
          const p = updatedProducts[pIdx];
          const newStock = p.currentStock + oldItem.quantity;
          updatedProducts[pIdx] = { ...p, currentStock: newStock };
        }
      });

      // 2. Deduct new items stock
      updatedData.items.forEach(newItem => {
        const pIdx = updatedProducts.findIndex(p => p.id === newItem.productId);
        if (pIdx !== -1) {
          const p = updatedProducts[pIdx];
          const prevStock = p.currentStock;
          const newStock = Math.max(0, p.currentStock - newItem.quantity);
          updatedProducts[pIdx] = { ...p, currentStock: newStock };

          generatedMovements.push({
            id: 'mov-' + Date.now() + Math.random(),
            date: nowStr,
            productId: p.id,
            productCode: p.code,
            productName: p.name,
            type: 'adjustment',
            quantity: newItem.quantity,
            previousStock: prevStock,
            newStock: newStock,
            reference: existingInvoice.invoiceNumber,
            reason: `Ajustement suite modification Facture ${existingInvoice.invoiceNumber} (${updatedData.customerName || existingInvoice.customerName})`,
            location: p.location,
            performedBy: currentUser.name,
          });
        }
      });

      if (generatedMovements.length > 0) {
        setStockMovements(prev => {
          const next = [...generatedMovements, ...prev];
          updateDocValue('stockMovements', next);
          return next;
        });
      }

      setProducts(updatedProducts);
      updateDocValue('products', updatedProducts);
    }

    // Recalculate totals
    const items = updatedData.items || existingInvoice.items;
    const subtotal = updatedData.subtotal !== undefined
      ? updatedData.subtotal
      : items.reduce((sum, it) => sum + (it.subtotal || it.total || (it.quantity * it.unitPrice * (1 - (it.discount || 0) / 100))), 0);

    const vatAmount = updatedData.vatAmount !== undefined
      ? updatedData.vatAmount
      : Math.round((subtotal * (companySettings.defaultVatRate || 0)) / 100);

    const discountAmount = updatedData.discountAmount !== undefined
      ? updatedData.discountAmount
      : (existingInvoice.discountAmount || 0);

    const totalAmount = updatedData.totalAmount !== undefined
      ? updatedData.totalAmount
      : Math.round(subtotal + vatAmount - discountAmount);

    const paidAmount = updatedData.paidAmount !== undefined
      ? updatedData.paidAmount
      : existingInvoice.paidAmount;

    const remainingAmount = Math.max(0, totalAmount - paidAmount);
    const status = updatedData.status || (remainingAmount === 0 ? 'paid' : paidAmount > 0 ? 'partial' : 'unpaid');

    const mergedInvoice: Invoice = {
      ...existingInvoice,
      ...updatedData,
      items,
      subtotal,
      vatAmount,
      discountAmount,
      totalAmount,
      paidAmount,
      remainingAmount,
      status,
    };

    setInvoices(prev => {
      const next = prev.map(inv => inv.id === id ? mergedInvoice : inv);
      updateDocValue('invoices', next);
      return next;
    });

    setNotifications(prev => {
      const next = [
        {
          id: 'notif-' + Date.now(),
          type: 'unpaid_invoice' as const,
          title: 'Facture Modifiée',
          message: `La facture ${existingInvoice.invoiceNumber} (${mergedInvoice.customerName}) a été mise à jour avec succès.`,
          date: nowStr,
          read: false,
          severity: 'info' as const,
          linkTab: 'invoices',
        },
        ...prev
      ];
      updateDocValue('notifications', next);
      return next;
    });
  };

  // Delete Invoice
  const deleteInvoice = (id: string, options: { restoreStock?: boolean } = { restoreStock: true }) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de facture');
      return;
    }
    const existingInvoice = invoices.find(inv => inv.id === id);
    if (!existingInvoice) return;

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    // Reintegrate stocks
    if (options.restoreStock !== false) {
      let updatedProducts = [...products];
      const generatedMovements: StockMovement[] = [];

      existingInvoice.items.forEach(item => {
        const pIdx = updatedProducts.findIndex(p => p.id === item.productId);
        if (pIdx !== -1) {
          const p = updatedProducts[pIdx];
          const prevStock = p.currentStock;
          const newStock = p.currentStock + item.quantity;
          updatedProducts[pIdx] = { ...p, currentStock: newStock };

          generatedMovements.push({
            id: 'mov-' + Date.now() + Math.random(),
            date: nowStr,
            productId: p.id,
            productCode: p.code,
            productName: p.name,
            type: 'in',
            quantity: item.quantity,
            previousStock: prevStock,
            newStock: newStock,
            reference: existingInvoice.invoiceNumber,
            reason: `Réintégration de stock suite à annulation/suppression de la Facture ${existingInvoice.invoiceNumber} (${existingInvoice.customerName})`,
            location: p.location,
            performedBy: currentUser.name,
          });
        }
      });

      if (generatedMovements.length > 0) {
        setStockMovements(prev => {
          const next = [...generatedMovements, ...prev];
          updateDocValue('stockMovements', next);
          return next;
        });
      }

      setProducts(updatedProducts);
      updateDocValue('products', updatedProducts);
    }

    // Delete invoice from array
    setInvoices(prev => {
      const next = prev.filter(inv => inv.id !== id);
      updateDocValue('invoices', next);
      return next;
    });

    setNotifications(prev => {
      const next = [
        {
          id: 'notif-' + Date.now(),
          type: 'unpaid_invoice' as const,
          title: 'Facture Supprimée',
          message: `La facture ${existingInvoice.invoiceNumber} a été supprimée. ${options.restoreStock !== false ? 'Les stocks ont été réintégrés.' : ''}`,
          date: nowStr,
          read: false,
          severity: 'warning' as const,
          linkTab: 'invoices',
        },
        ...prev
      ];
      updateDocValue('notifications', next);
      return next;
    });
  };

  // Add Payment to Invoice helper
  const addPaymentToInvoice = (invoiceId: string, amount: number, paymentMethod: string = 'cash', notes: string = '') => {
    const inv = invoices.find(i => i.id === invoiceId);
    if (!inv || amount <= 0) return;

    addPayment({
      reference: `REC-2026-${String(payments.length + 1).padStart(3, '0')}`,
      date: new Date().toISOString().split('T')[0],
      type: 'sale',
      targetId: inv.id,
      targetNumber: inv.invoiceNumber,
      entityId: inv.customerId,
      entityName: inv.customerName,
      amount: amount,
      paymentMethod: paymentMethod as PaymentMethod,
      notes: notes || `Règlement facture ${inv.invoiceNumber}`,
      receivedBy: currentUser.name,
    });
  };

  // Create Purchase Order
  const createPurchaseOrder = (purchaseData: Omit<PurchaseOrder, 'id' | 'orderNumber'>): PurchaseOrder => {
    const poCount = purchases.length + 1;
    const poNum = `BA-2026-${String(poCount).padStart(4, '0')}`;

    const newPO: PurchaseOrder = {
      ...purchaseData,
      id: 'po-' + Date.now(),
      orderNumber: poNum,
    };

    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    let updatedProducts = [...products];
    const generatedMovements: StockMovement[] = [];

    purchaseData.items.forEach(item => {
      const idx = updatedProducts.findIndex(p => p.id === item.productId);
      if (idx !== -1) {
        const p = updatedProducts[idx];
        const newStock = p.currentStock + item.quantity;
        
        generatedMovements.push({
          id: 'mov-' + Date.now() + Math.random(),
          date: nowStr,
          productId: p.id,
          productCode: p.code,
          productName: p.name,
          type: 'in',
          quantity: item.quantity,
          previousStock: p.currentStock,
          newStock: newStock,
          reference: poNum,
          reason: `Réception Achat Bon ${poNum} (${newPO.supplierName})`,
          location: p.location,
          performedBy: currentUser.name,
        });

        updatedProducts[idx] = { ...p, currentStock: newStock, buyPrice: item.unitCost };
      }
    });

    if (generatedMovements.length > 0) {
      setStockMovements(prev => {
        const next = [...generatedMovements, ...prev];
        updateDocValue('stockMovements', next);
        return next;
      });
    }

    setProducts(updatedProducts);
    updateDocValue('products', updatedProducts);

    // Update supplier balance (debt owed to supplier = remainingAmount)
    setSuppliers(prev => {
      const next = prev.map(s => {
        if (s.id === newPO.supplierId) {
          return { ...s, balance: s.balance + newPO.remainingAmount };
        }
        return s;
      });
      updateDocValue('suppliers', next);
      return next;
    });

    // Record payment if paidAmount > 0
    if (newPO.paidAmount > 0) {
      addPayment({
        reference: `REC-2026-${String(payments.length + 1).padStart(3, '0')}`,
        date: newPO.date,
        type: 'purchase',
        targetId: newPO.id,
        targetNumber: poNum,
        entityId: newPO.supplierId,
        entityName: newPO.supplierName,
        amount: newPO.paidAmount,
        paymentMethod: 'transfer',
        notes: `Règlement d'achat ${poNum}`,
        receivedBy: currentUser.name,
      });
    }

    setPurchases(prev => {
      const next = [newPO, ...prev];
      updateDocValue('purchases', next);
      return next;
    });

    // Send notification
    setNotifications(prev => {
      const next = [
        {
          id: 'notif-' + Date.now(),
          type: 'new_purchase' as const,
          title: 'Nouveau Bon d\'Achat',
          message: `Bon d'achat ${poNum} enregistré pour ${newPO.supplierName} (${newPO.totalAmount.toLocaleString()} CFA).`,
          date: nowStr,
          read: false,
          severity: 'info' as const,
          linkTab: 'purchases',
        },
        ...prev
      ];
      updateDocValue('notifications', next);
      return next;
    });

    return newPO;
  };

  // Add Payment
  const addPayment = (paymentData: Omit<PaymentRecord, 'id'>): PaymentRecord => {
    const payRef = paymentData.reference || `REC-2026-${String(payments.length + 1).padStart(3, '0')}`;
    const newPay: PaymentRecord = {
      ...paymentData,
      id: 'pay-' + Date.now(),
      reference: payRef,
    };

    if (paymentData.type === 'sale') {
      // Update invoice paid & remaining amounts
      setInvoices(prev => {
        const next = prev.map(inv => {
          if (inv.id === paymentData.targetId) {
            const newPaid = inv.paidAmount + paymentData.amount;
            const newRemaining = Math.max(0, inv.totalAmount - newPaid);
            let newStatus = inv.status;
            if (newRemaining === 0) newStatus = 'paid';
            else if (newPaid > 0) newStatus = 'partial';
            return { ...inv, paidAmount: newPaid, remainingAmount: newRemaining, status: newStatus };
          }
          return inv;
        });
        updateDocValue('invoices', next);
        return next;
      });
    } else {
      // Update purchase paid & remaining amounts
      setPurchases(prev => {
        const next = prev.map(po => {
          if (po.id === paymentData.targetId) {
            const newPaid = po.paidAmount + paymentData.amount;
            const newRemaining = Math.max(0, po.totalAmount - newPaid);
            let newStatus = po.status;
            if (newRemaining === 0) newStatus = 'paid';
            else if (newPaid > 0) newStatus = 'partial';
            return { ...po, paidAmount: newPaid, remainingAmount: newRemaining, status: newStatus };
          }
          return po;
        });
        updateDocValue('purchases', next);
        return next;
      });

      // Reduce supplier debt balance
      setSuppliers(prev => {
        const next = prev.map(sup => {
          if (sup.id === paymentData.entityId) {
            return { ...sup, balance: Math.max(0, sup.balance - paymentData.amount) };
          }
          return sup;
        });
        updateDocValue('suppliers', next);
        return next;
      });
    }

    setPayments(prev => {
      const next = [newPay, ...prev];
      updateDocValue('payments', next);
      return next;
    });

    // Trigger payment notification
    setNotifications(prev => {
      const next = [
        {
          id: 'notif-' + Date.now(),
          type: 'payment_received' as const,
          title: 'Paiement Enregistré',
          message: `Paiement de ${paymentData.amount.toLocaleString()} CFA reçu de ${paymentData.entityName} (${paymentData.targetNumber}).`,
          date: new Date().toISOString().replace('T', ' ').substring(0, 16),
          read: false,
          severity: 'success' as const,
          linkTab: 'payments',
        },
        ...prev
      ];
      updateDocValue('notifications', next);
      return next;
    });

    return newPay;
  };

  // Stock Movement Log
  const addStockMovement = (mov: Omit<StockMovement, 'id'>) => {
    const newMov: StockMovement = {
      ...mov,
      id: 'mov-' + Date.now(),
    };
    setStockMovements(prev => {
      const next = [newMov, ...prev];
      updateDocValue('stockMovements', next);
      return next;
    });
  };

  // Stock Adjustment (Admin only)
  const adjustStock = (productId: string, newStock: number, reason: string = 'Ajustement inventaire') => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Ajustement de stock');
      return;
    }
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    const prevStock = prod.currentStock;
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const updatedProducts = products.map(p => p.id === productId ? { ...p, currentStock: newStock } : p);
    setProducts(updatedProducts);
    updateDocValue('products', updatedProducts);

    addStockMovement({
      date: nowStr,
      productId: prod.id,
      productCode: prod.code,
      productName: prod.name,
      type: 'adjustment',
      quantity: Math.abs(newStock - prevStock),
      previousStock: prevStock,
      newStock: newStock,
      reason: reason,
      location: prod.location,
      performedBy: currentUser.name,
    });
  };

  // Stock Entry (Add cartons or units with automatic proportional calculation & persistent database sync)
  const addStockEntry = (
    productId: string,
    quantityToAdd: number,
    mode: 'cartons' | 'pieces' = 'cartons',
    reason: string = 'Réception approvisionnement / Entrée stock'
  ) => {
    const prodsList = productsRef.current || products;
    const prod = prodsList.find(p => p.id === productId);
    if (!prod) return;

    const piecesPerBox = prod.piecesPerBox && prod.piecesPerBox > 0
      ? prod.piecesPerBox
      : (prod.unit.toLowerCase() === 'carton' ? 1 : 10);

    const actualPiecesAdded = mode === 'cartons' ? quantityToAdd * piecesPerBox : quantityToAdd;
    if (actualPiecesAdded <= 0) return;

    const prevStock = prod.currentStock;
    const newStock = prevStock + actualPiecesAdded;
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const updatedProducts = prodsList.map(p => p.id === productId ? { ...p, currentStock: newStock } : p);
    setProducts(updatedProducts);
    updateDocValue('products', updatedProducts);

    const cartonLabel = mode === 'cartons'
      ? `+${quantityToAdd} carton${quantityToAdd > 1 ? 's' : ''} (+${actualPiecesAdded} ${prod.unit}s)`
      : `+${quantityToAdd} ${prod.unit}${quantityToAdd > 1 ? 's' : ''}`;

    addStockMovement({
      date: nowStr,
      productId: prod.id,
      productCode: prod.code,
      productName: prod.name,
      type: 'in',
      quantity: actualPiecesAdded,
      previousStock: prevStock,
      newStock: newStock,
      reason: `${reason} (${cartonLabel})`,
      location: prod.location,
      performedBy: currentUser.name,
    });

    setNotifications(prev => {
      const next = [
        {
          id: 'notif-' + Date.now(),
          type: 'new_purchase' as const,
          title: 'Entrée de Stock Enregistrée',
          message: `${cartonLabel} ajouté(s) à ${prod.name}. Stock total : ${newStock} ${prod.unit}s.`,
          date: nowStr,
          read: false,
          severity: 'success' as const,
          linkTab: 'inventory'
        },
        ...prev
      ];
      updateDocValue('notifications', next);
      return next;
    });
  };

  // Delete Purchase Order (Admin only)
  const deletePurchaseOrder = (id: string) => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Suppression de bon d\'achat');
      return;
    }
    setPurchases(prev => {
      const next = prev.filter(po => po.id !== id);
      updateDocValue('purchases', next);
      return next;
    });
  };

  // Notification actions
  const markNotificationAsRead = (id: string) => {
    setNotifications(prev => {
      const next = prev.map(n => n.id === id ? { ...n, read: true } : n);
      updateDocValue('notifications', next);
      return next;
    });
  };
  const clearAllNotifications = () => {
    setNotifications([]);
    updateDocValue('notifications', []);
  };

  // Reset Demo Data
  const resetDemoData = () => {
    setCompanySettings(initialCompanySettings);
    updateDocValue('settings', initialCompanySettings);

    setCategories(initialCategories);
    updateDocValue('categories', initialCategories);

    setProducts(initialProducts);
    updateDocValue('products', initialProducts);

    setSuppliers(initialSuppliers);
    updateDocValue('suppliers', initialSuppliers);

    setCustomers(initialCustomers);
    updateDocValue('customers', initialCustomers);

    setInvoices(initialInvoices);
    updateDocValue('invoices', initialInvoices);

    setPurchases(initialPurchases);
    updateDocValue('purchases', initialPurchases);

    setPayments(initialPayments);
    updateDocValue('payments', initialPayments);

    setStockMovements(initialStockMovements);
    updateDocValue('stockMovements', initialStockMovements);

    setNotifications(initialNotifications);
    updateDocValue('notifications', initialNotifications);

    setUsers(initialUsers);
    updateDocValue('users', initialUsers);

    setStores(initialStores);
    updateDocValue('stores', initialStores);

    localStorage.clear();
  };

  // Full Database Backup Export
  const exportDatabaseBackup = () => {
    const backupData = {
      version: '1.0.0',
      appName: 'ALANWARY BUSINESS INTERNATIONAL - Stock & Ventes ERP',
      exportedAt: new Date().toISOString(),
      recordCounts: {
        products: products.length,
        invoices: invoices.length,
        customers: customers.length,
        suppliers: suppliers.length,
        categories: categories.length,
        purchases: purchases.length,
        payments: payments.length,
        stockMovements: stockMovements.length,
        users: users.length,
        stores: stores.length
      },
      data: {
        settings: companySettings,
        categories,
        products,
        suppliers,
        customers,
        invoices,
        purchases,
        payments,
        stockMovements,
        notifications,
        users,
        stores
      }
    };

    const jsonStr = JSON.stringify(backupData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sauvegarde-odooerp-${new Date().toISOString().split('T')[0]}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Full Database Backup Restore
  const importDatabaseBackup = async (backupData: any): Promise<{ success: boolean; message: string; counts?: Record<string, number> }> => {
    if (currentUser?.role !== 'admin') {
      notifyUnauthorized('Restauration de base de données');
      return { success: false, message: "Action réservée à l'administrateur." };
    }

    try {
      const rawData = backupData.data || backupData;
      if (!rawData || typeof rawData !== 'object') {
        return { success: false, message: 'Format de fichier JSON invalide.' };
      }

      if (rawData.settings) {
        setCompanySettings(rawData.settings);
        updateDocValue('settings', rawData.settings);
      }
      if (Array.isArray(rawData.categories)) {
        setCategories(rawData.categories);
        updateDocValue('categories', rawData.categories);
      }
      if (Array.isArray(rawData.products)) {
        setProducts(rawData.products);
        updateDocValue('products', rawData.products);
      }
      if (Array.isArray(rawData.suppliers)) {
        setSuppliers(rawData.suppliers);
        updateDocValue('suppliers', rawData.suppliers);
      }
      if (Array.isArray(rawData.customers)) {
        setCustomers(rawData.customers);
        updateDocValue('customers', rawData.customers);
      }
      if (Array.isArray(rawData.invoices)) {
        setInvoices(rawData.invoices);
        updateDocValue('invoices', rawData.invoices);
      }
      if (Array.isArray(rawData.purchases)) {
        setPurchases(rawData.purchases);
        updateDocValue('purchases', rawData.purchases);
      }
      if (Array.isArray(rawData.payments)) {
        setPayments(rawData.payments);
        updateDocValue('payments', rawData.payments);
      }
      if (Array.isArray(rawData.stockMovements)) {
        setStockMovements(rawData.stockMovements);
        updateDocValue('stockMovements', rawData.stockMovements);
      }
      if (Array.isArray(rawData.stores)) {
        setStores(rawData.stores);
        updateDocValue('stores', rawData.stores);
      }
      if (Array.isArray(rawData.users)) {
        setUsers(rawData.users);
        updateDocValue('users', rawData.users);
      }

      const counts = {
        products: Array.isArray(rawData.products) ? rawData.products.length : products.length,
        invoices: Array.isArray(rawData.invoices) ? rawData.invoices.length : invoices.length,
        customers: Array.isArray(rawData.customers) ? rawData.customers.length : customers.length,
        suppliers: Array.isArray(rawData.suppliers) ? rawData.suppliers.length : suppliers.length,
      };

      setNotifications(prev => [
        {
          id: 'notif-' + Date.now(),
          type: 'new_purchase' as const,
          title: 'Base de Données Restaurée',
          message: `Restauration effectuée : ${counts.products} produits, ${counts.invoices} factures, ${counts.customers} clients.`,
          date: new Date().toISOString().replace('T', ' ').substring(0, 16),
          read: false,
          severity: 'success' as const,
          linkTab: 'settings'
        },
        ...prev
      ]);

      return {
        success: true,
        message: 'Base de données restaurée avec succès et synchronisée dans le Cloud !',
        counts
      };
    } catch (err: any) {
      console.error('Erreur de restauration:', err);
      return { success: false, message: err?.message || 'Erreur lors de la restauration du fichier.' };
    }
  };

  // Force Cloud Sync of All Collections
  const forceCloudSync = async (): Promise<{ success: boolean; message: string; timestamp: string }> => {
    const allState = {
      settings: companySettings,
      categories,
      products,
      suppliers,
      customers,
      invoices,
      purchases,
      payments,
      stockMovements,
      notifications,
      users,
      stores
    };

    const res = await forceSaveAllToCloud(allState);
    if (res.success) {
      return {
        success: true,
        message: 'Toutes les collections (12 modules) ont été enregistrées avec succès dans Firestore.',
        timestamp: res.timestamp
      };
    } else {
      return {
        success: false,
        message: `Erreur d'enregistrement pour: ${res.failedKeys.join(', ')}`,
        timestamp: res.timestamp
      };
    }
  };

  // Translation helper function
  const t = (key: string): string => {
    const langDict = translations[language] || {};
    return langDict[key] || key;
  };

  return (
    <ERPContext.Provider
      value={{
        activeTab,
        setActiveTab,
        language,
        setLanguage,
        theme,
        setTheme,
        currentUser,
        setCurrentUser,
        globalSearchOpen,
        setGlobalSearchOpen,

        companySettings,
        updateCompanySettings,

        categories,
        addCategory,
        updateCategory,
        deleteCategory,

        products,
        addProduct,
        updateProduct,
        deleteProduct,

        suppliers,
        addSupplier,
        updateSupplier,
        deleteSupplier,

        customers,
        addCustomer,
        updateCustomer,
        deleteCustomer,

        debtors,

        invoices,
        createInvoice,
        updateInvoice,
        deleteInvoice,
        addPaymentToInvoice,

        purchases,
        createPurchaseOrder,

        payments,
        addPayment,

        stockMovements,
        addStockMovement,

        notifications,
        markNotificationAsRead,
        clearAllNotifications,

        users,
        addUser,
        updateUser,
        deleteUser,
        stores,
        addStore,
        canAccessTab,
        isAdmin,
        adjustStock,
        addStockEntry,
        deletePurchaseOrder,
        isAuthenticated,
        login,
        logout,
        exportDatabaseBackup,
        importDatabaseBackup,
        forceCloudSync,
        resetDemoData,
        t,
      }}
    >
      {children}
    </ERPContext.Provider>
  );
};

export const useERP = () => {
  const context = useContext(ERPContext);
  if (!context) {
    throw new Error('useERP must be used within an ERPProvider');
  }
  return context;
};
